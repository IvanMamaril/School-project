﻿namespace MamarilVideoShop
{
    partial class frmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblcarry = new System.Windows.Forms.Label();
            this.lblpicuser = new System.Windows.Forms.Label();
            this.lblpiccashier = new System.Windows.Forms.Label();
            this.close = new System.Windows.Forms.Label();
            this.lblpicvideo = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblpicdemo = new System.Windows.Forms.Label();
            this.picdemo = new System.Windows.Forms.PictureBox();
            this.picvideo = new System.Windows.Forms.PictureBox();
            this.piccashier = new System.Windows.Forms.PictureBox();
            this.picuser = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picdemo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picvideo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.piccashier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picuser)).BeginInit();
            this.SuspendLayout();
            // 
            // lblcarry
            // 
            this.lblcarry.AutoSize = true;
            this.lblcarry.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblcarry.Location = new System.Drawing.Point(540, 18);
            this.lblcarry.Name = "lblcarry";
            this.lblcarry.Size = new System.Drawing.Size(0, 13);
            this.lblcarry.TabIndex = 0;
            // 
            // lblpicuser
            // 
            this.lblpicuser.AutoSize = true;
            this.lblpicuser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpicuser.Location = new System.Drawing.Point(129, 92);
            this.lblpicuser.Name = "lblpicuser";
            this.lblpicuser.Size = new System.Drawing.Size(149, 20);
            this.lblpicuser.TabIndex = 2;
            this.lblpicuser.Text = "Customer Record";
            this.lblpicuser.Visible = false;
            // 
            // lblpiccashier
            // 
            this.lblpiccashier.AutoSize = true;
            this.lblpiccashier.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpiccashier.Location = new System.Drawing.Point(129, 172);
            this.lblpiccashier.Name = "lblpiccashier";
            this.lblpiccashier.Size = new System.Drawing.Size(94, 20);
            this.lblpiccashier.TabIndex = 4;
            this.lblpiccashier.Text = "Cashiering";
            this.lblpiccashier.Visible = false;
            // 
            // close
            // 
            this.close.AutoSize = true;
            this.close.BackColor = System.Drawing.Color.Transparent;
            this.close.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close.ForeColor = System.Drawing.Color.SlateGray;
            this.close.Location = new System.Drawing.Point(560, 9);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(21, 20);
            this.close.TabIndex = 9;
            this.close.Text = "X";
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // lblpicvideo
            // 
            this.lblpicvideo.AutoSize = true;
            this.lblpicvideo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpicvideo.Location = new System.Drawing.Point(378, 172);
            this.lblpicvideo.Name = "lblpicvideo";
            this.lblpicvideo.Size = new System.Drawing.Size(64, 20);
            this.lblpicvideo.TabIndex = 11;
            this.lblpicvideo.Text = "Videos";
            this.lblpicvideo.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkGray;
            this.label2.Location = new System.Drawing.Point(50, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 20);
            this.label2.TabIndex = 27;
            this.label2.Text = "Menu";
            // 
            // lblpicdemo
            // 
            this.lblpicdemo.AutoSize = true;
            this.lblpicdemo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpicdemo.Location = new System.Drawing.Point(378, 92);
            this.lblpicdemo.Name = "lblpicdemo";
            this.lblpicdemo.Size = new System.Drawing.Size(56, 20);
            this.lblpicdemo.TabIndex = 29;
            this.lblpicdemo.Text = "Demo";
            this.lblpicdemo.Visible = false;
            // 
            // picdemo
            // 
            this.picdemo.BackColor = System.Drawing.SystemColors.Control;
            this.picdemo.BackgroundImage = global::MamarilVideoShop.Properties.Resources.calendar;
            this.picdemo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picdemo.Location = new System.Drawing.Point(302, 64);
            this.picdemo.Name = "picdemo";
            this.picdemo.Size = new System.Drawing.Size(70, 70);
            this.picdemo.TabIndex = 28;
            this.picdemo.TabStop = false;
            this.picdemo.Click += new System.EventHandler(this.picdemo_Click);
            this.picdemo.MouseLeave += new System.EventHandler(this.picdemo_MouseLeave);
            this.picdemo.MouseHover += new System.EventHandler(this.picdemo_MouseHover);
            // 
            // picvideo
            // 
            this.picvideo.BackColor = System.Drawing.SystemColors.Control;
            this.picvideo.BackgroundImage = global::MamarilVideoShop.Properties.Resources.video;
            this.picvideo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picvideo.Location = new System.Drawing.Point(302, 144);
            this.picvideo.Name = "picvideo";
            this.picvideo.Size = new System.Drawing.Size(70, 70);
            this.picvideo.TabIndex = 10;
            this.picvideo.TabStop = false;
            this.picvideo.Click += new System.EventHandler(this.picvideo_Click);
            this.picvideo.MouseLeave += new System.EventHandler(this.picvideo_MouseLeave);
            this.picvideo.MouseHover += new System.EventHandler(this.picvideo_MouseHover);
            // 
            // piccashier
            // 
            this.piccashier.BackgroundImage = global::MamarilVideoShop.Properties.Resources.cashier;
            this.piccashier.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.piccashier.Location = new System.Drawing.Point(53, 144);
            this.piccashier.Name = "piccashier";
            this.piccashier.Size = new System.Drawing.Size(70, 70);
            this.piccashier.TabIndex = 3;
            this.piccashier.TabStop = false;
            this.piccashier.Click += new System.EventHandler(this.piccashier_Click);
            this.piccashier.MouseLeave += new System.EventHandler(this.piccashier_MouseLeave);
            this.piccashier.MouseHover += new System.EventHandler(this.piccashier_MouseHover);
            // 
            // picuser
            // 
            this.picuser.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.picuser.BackgroundImage = global::MamarilVideoShop.Properties.Resources.user_black;
            this.picuser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picuser.Location = new System.Drawing.Point(53, 64);
            this.picuser.Name = "picuser";
            this.picuser.Size = new System.Drawing.Size(70, 70);
            this.picuser.TabIndex = 1;
            this.picuser.TabStop = false;
            this.picuser.Click += new System.EventHandler(this.picuser_Click);
            this.picuser.MouseLeave += new System.EventHandler(this.picuser_MouseLeave);
            this.picuser.MouseHover += new System.EventHandler(this.picuser_MouseHover);
            // 
            // frmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(593, 334);
            this.Controls.Add(this.lblpicdemo);
            this.Controls.Add(this.picdemo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblpicvideo);
            this.Controls.Add(this.picvideo);
            this.Controls.Add(this.close);
            this.Controls.Add(this.lblpiccashier);
            this.Controls.Add(this.piccashier);
            this.Controls.Add(this.lblpicuser);
            this.Controls.Add(this.picuser);
            this.Controls.Add(this.lblcarry);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmMenu";
            this.Load += new System.EventHandler(this.frmMenu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picdemo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picvideo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.piccashier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picuser)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblcarry;
        private System.Windows.Forms.PictureBox picuser;
        private System.Windows.Forms.Label lblpicuser;
        private System.Windows.Forms.Label lblpiccashier;
        private System.Windows.Forms.PictureBox piccashier;
        private System.Windows.Forms.Label close;
        private System.Windows.Forms.Label lblpicvideo;
        private System.Windows.Forms.PictureBox picvideo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblpicdemo;
        private System.Windows.Forms.PictureBox picdemo;
    }
}