﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System.Data;

namespace MamarilVideoShop
{
    class Rating
    {
        MySqlConnection conn = null;

        public Rating()
        {
            String hostname = "localhost";
            String database = "videoshop";
            String username = "root";
            String password = "";

            conn = new MySqlConnection(
                "host=" + hostname +
                ";database=" + database +
                ";username=" + username +
                ";password=" + password + ";");
        }

        private bool Open()
        {
            try
            {
                conn.Open();
                return true;
            }
            catch
            {
                MessageBox.Show("Unable to connect to database!");
                return false;
            }
        }

        private bool Close()
        {
            try
            {
                conn.Close();
                return true;
            }
            catch
            {
                MessageBox.Show("Unable to connect to database!");
                return false;
            }
        }

        public DataGridView getRateRecords(DataGridView datagrid)
        {
            String table = "rating";
            String query = "select * from " + table;

            MySqlDataAdapter da = null;
            DataSet ds = null;
            conn.Open();
            ds = new DataSet();
            da = new MySqlDataAdapter(query, conn);
            da.Fill(ds, table);

            datagrid.DataSource = ds.Tables[table];
            return datagrid;
        }

        public void newRate(String ratingid, String ratingdesc)
        {
            String table = "rating";
            String columns = "ratingid,ratingdesc";
            String query = "INSERT INTO " + table +
                                     " (" + columns +
                             ") VALUES ('" + ratingid + "'," +
                                       "'" + ratingdesc + "')";
            try
            {
                if (this.Open())
                {
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    this.Close();
                }
            }
            catch { }
        }

        public void updateRate(String ratingid, String ratingdesc)
        {
            String table = "rating";
            String query = "UPDATE " + table + " SET " +
                             "ratingdesc='" + ratingdesc + "'" +
                             " WHERE ratingid='" + ratingid + "'";
            try
            {
                if (this.Open())
                {
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    this.Close();
                }
            }
            catch { }
        }

        public void deleteRate(String ratingid)
        {
            String table = "rating";
            String query = "DELETE FROM " + table +
                             " WHERE ratingid='" + ratingid + "'";
            try
            {
                if (this.Open())
                {
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    this.Close();
                }
            }
            catch { }
        }

        public void searchBook(String ratingid)
        {
            MessageBox.Show(ratingid);
        }
    }
}
