﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using MySql.Data.MySqlClient;

namespace MamarilVideoShop
{
    public partial class frmDemo : Form
    {
        public frmDemo()
        {
            InitializeComponent();
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void insert_Click(object sender, EventArgs e)
        {
            //under development //saves date and demoid //no current function to the system
            dtpdemo.Format = DateTimePickerFormat.Custom;
            dtpdemo.CustomFormat = "yyyy-MM-dd";

            String dateChosen = dtpdemo.Text;

            MySqlConnection conn= new
            MySqlConnection("host=localhost;database=videoshop;username=root;password=;");
            conn.Open();
            String query= "INSERT INTO demo (demoid,demodate) VALUES(NULL, '"+ dateChosen +"');";
            MySqlCommand cmd = new MySqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Date Inserted!");
        }

        private void insert_MouseHover(object sender, EventArgs e)
        {
            insert.ForeColor = Color.Maroon;
        }

        private void insert_MouseLeave(object sender, EventArgs e)
        {
            insert.ForeColor = Color.DarkGray;
        }
    }
}
