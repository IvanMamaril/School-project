﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace MamarilVideoShop
{
    class Video
    {
        MySqlConnection conn = null;

        public Video()
        {
            String hostname = "localhost";
            String database = "videoshop";
            String username = "root";
            String password = "";

            conn = new MySqlConnection(
                "host=" + hostname +
                ";database=" + database +
                ";username=" + username +
                ";password=" + password + ";");
        }

        private bool Open()
        {
            try
            {
                conn.Open();
                return true;
            }
            catch
            {
                MessageBox.Show("Unable to connect to database!");
                return false;
            }
        }

        private bool Close()
        {
            try
            {
                conn.Close();
                return true;
            }
            catch
            {
                MessageBox.Show("Unable to connect to database!");
                return false;
            }
        }

        public DataGridView getVideoRecords(DataGridView datagrid)
        {
            String table = "video";
            String query = "select dvdid,dvdname,dvdcopydate,dvdprodcompany,dvdminutes,ratingid,catid,dvdprice,dvdcover from " + table;

            MySqlDataAdapter da = null;
            DataSet ds = null;
            conn.Open();
            ds = new DataSet();
            da = new MySqlDataAdapter(query, conn);
            da.Fill(ds, table);

            datagrid.DataSource = ds.Tables[table];
            return datagrid;
        }

        public void newVideo(String dvdid, String dvdname, String dvdcopydate, String dvdprodcompany, String dvdminutes, String ratingid, String catid, String dvdprice, OpenFileDialog ofd)
        {

            String file = ofd.FileName;
            byte[] Imagedata;
            FileStream fs = new FileStream(file, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            Imagedata = br.ReadBytes((int)fs.Length);
            br.Close();
            fs.Close();

            String table = "video";
            String columns = "dvdid,dvdname,dvdcopydate,dvdprodcompany,dvdminutes,ratingid,catid,dvdprice,dvdcover";
            String query = "INSERT INTO " + table +
                                     " (" + columns +
                             ") VALUES ('" + dvdid + "'," +
                                       "'" + dvdname + "'," +
                                       "'" + dvdcopydate + "'," +
                                       "'" + dvdprodcompany + "'," +
                                       "'" + dvdminutes + "'," +
                                       "'" + ratingid + "'," +
                                       "'" + catid + "'," +
                                       "'" + dvdprice + "'," +
                                       "@Image)";

            


            
            try
            {
                if (this.Open())
                {
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.Add("@Image", MySqlDbType.Blob);
                    cmd.Parameters["@Image"].Value = Imagedata;
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch { }
        }

        public void updateVideo(String dvdid, String dvdname, String dvdcopydate, String dvdprodcompany, String dvdminutes, String ratingid, String catid, String dvdprice, OpenFileDialog ofd)
        {

         //   if (ofd != null)
         //   {
                String file = ofd.FileName;
                byte[] Imagedata;
                FileStream fs = new FileStream(file, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                Imagedata = br.ReadBytes((int)fs.Length);
                br.Close();
                fs.Close();


                String table = "video";
                String query = "UPDATE " + table + " SET " +
                                 "dvdname='" + dvdname + "'," +
                                 "dvdcopydate ='" + dvdcopydate + "'," +
                                 "dvdprodcompany='" + dvdprodcompany + "'," +
                                 "dvdminutes='" + dvdminutes + "'," +
                                 "ratingid='" + ratingid + "'," +
                                 "catid='" + catid + "'," +
                                 "dvdprice='" + dvdprice + "'," +
                                 "dvdcover=@Image" +
                                 " WHERE dvdid='" + dvdid + "'";





                try
                {
                    if (this.Open())
                    {

                        MySqlCommand cmd = new MySqlCommand(query, conn);
                        cmd.Parameters.Add("@Image", MySqlDbType.Blob);
                        cmd.Parameters["@Image"].Value = Imagedata;
                        cmd.ExecuteNonQuery();
                        conn.Close();
                    }
                }
                catch { }
       //     }
      /*      else
            {
                String table = "video";
                String query = "UPDATE " + table + " SET " +
                                 "dvdname='" + dvdname + "'," +
                                 "dvdcopydate ='" + dvdcopydate + "'," +
                                 "dvdprodcompany='" + dvdprodcompany + "'," +
                                 "dvdminutes='" + dvdminutes + "'," +
                                 "ratingid='" + ratingid + "'," +
                                 "catid='" + catid + "'," +
                                 "dvdprice='" + dvdprice + "'," +
                                 "dvdcover=@Image" +
                                 " WHERE dvdid='" + dvdid + "'";





                try
                {
                    if (this.Open())
                    {

                        MySqlCommand cmd = new MySqlCommand(query, conn);
                        cmd.ExecuteNonQuery();
                        conn.Close();
                    }
                }
                catch { }
            }*/
        }

        public void deleteVideo(String dvdid)
        {
            String table = "video";
            String query = "DELETE FROM " + table +
                             " WHERE dvdid='" + dvdid + "'";
            try
            {
                if (this.Open())
                {
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    this.Close();
                }
            }
            catch { }
        }

        public void searchBook(String dvdid)
        {
            MessageBox.Show(dvdid);
        }
    }
}
