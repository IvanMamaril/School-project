﻿namespace MamarilVideoShop
{
    partial class frmQty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtci = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtri = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtdmin = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtdpc = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtdn = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtdid = new System.Windows.Forms.TextBox();
            this.lbldvdid = new System.Windows.Forms.Label();
            this.txtdcd = new System.Windows.Forms.TextBox();
            this.txtdp = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txttotal = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.minus = new System.Windows.Forms.Button();
            this.plus = new System.Windows.Forms.Button();
            this.txtqty = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.print = new System.Windows.Forms.Label();
            this.close = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtci
            // 
            this.txtci.BackColor = System.Drawing.Color.DarkGray;
            this.txtci.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtci.Location = new System.Drawing.Point(212, 197);
            this.txtci.Name = "txtci";
            this.txtci.ReadOnly = true;
            this.txtci.Size = new System.Drawing.Size(156, 20);
            this.txtci.TabIndex = 39;
            this.txtci.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkGray;
            this.label6.Location = new System.Drawing.Point(91, 197);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 20);
            this.label6.TabIndex = 38;
            this.label6.Text = "Category ID";
            // 
            // txtri
            // 
            this.txtri.BackColor = System.Drawing.Color.DarkGray;
            this.txtri.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtri.Location = new System.Drawing.Point(212, 171);
            this.txtri.Name = "txtri";
            this.txtri.ReadOnly = true;
            this.txtri.Size = new System.Drawing.Size(156, 20);
            this.txtri.TabIndex = 37;
            this.txtri.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DarkGray;
            this.label7.Location = new System.Drawing.Point(110, 171);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 20);
            this.label7.TabIndex = 36;
            this.label7.Text = "Rating ID";
            // 
            // txtdmin
            // 
            this.txtdmin.BackColor = System.Drawing.Color.DarkGray;
            this.txtdmin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdmin.Location = new System.Drawing.Point(212, 145);
            this.txtdmin.Name = "txtdmin";
            this.txtdmin.ReadOnly = true;
            this.txtdmin.Size = new System.Drawing.Size(156, 20);
            this.txtdmin.TabIndex = 35;
            this.txtdmin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkGray;
            this.label4.Location = new System.Drawing.Point(81, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 20);
            this.label4.TabIndex = 34;
            this.label4.Text = "DVD Minutes";
            // 
            // txtdpc
            // 
            this.txtdpc.BackColor = System.Drawing.Color.DarkGray;
            this.txtdpc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdpc.Location = new System.Drawing.Point(212, 119);
            this.txtdpc.Name = "txtdpc";
            this.txtdpc.ReadOnly = true;
            this.txtdpc.Size = new System.Drawing.Size(156, 20);
            this.txtdpc.TabIndex = 33;
            this.txtdpc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkGray;
            this.label3.Location = new System.Drawing.Point(23, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(173, 20);
            this.label3.TabIndex = 32;
            this.label3.Text = "DVD Prod. Company";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkGray;
            this.label2.Location = new System.Drawing.Point(60, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 20);
            this.label2.TabIndex = 31;
            this.label2.Text = "DVD Copy Date";
            // 
            // txtdn
            // 
            this.txtdn.BackColor = System.Drawing.Color.DarkGray;
            this.txtdn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdn.Location = new System.Drawing.Point(212, 67);
            this.txtdn.Name = "txtdn";
            this.txtdn.ReadOnly = true;
            this.txtdn.Size = new System.Drawing.Size(156, 20);
            this.txtdn.TabIndex = 30;
            this.txtdn.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGray;
            this.label1.Location = new System.Drawing.Point(98, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 20);
            this.label1.TabIndex = 29;
            this.label1.Text = "DVD Name";
            // 
            // txtdid
            // 
            this.txtdid.BackColor = System.Drawing.Color.DarkGray;
            this.txtdid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdid.Location = new System.Drawing.Point(212, 41);
            this.txtdid.Name = "txtdid";
            this.txtdid.ReadOnly = true;
            this.txtdid.Size = new System.Drawing.Size(156, 20);
            this.txtdid.TabIndex = 28;
            this.txtdid.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbldvdid
            // 
            this.lbldvdid.AutoSize = true;
            this.lbldvdid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldvdid.ForeColor = System.Drawing.Color.DarkGray;
            this.lbldvdid.Location = new System.Drawing.Point(125, 41);
            this.lbldvdid.Name = "lbldvdid";
            this.lbldvdid.Size = new System.Drawing.Size(71, 20);
            this.lbldvdid.TabIndex = 27;
            this.lbldvdid.Text = "DVD ID";
            // 
            // txtdcd
            // 
            this.txtdcd.BackColor = System.Drawing.Color.DarkGray;
            this.txtdcd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdcd.Location = new System.Drawing.Point(212, 93);
            this.txtdcd.Name = "txtdcd";
            this.txtdcd.ReadOnly = true;
            this.txtdcd.Size = new System.Drawing.Size(156, 20);
            this.txtdcd.TabIndex = 40;
            this.txtdcd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtdp
            // 
            this.txtdp.BackColor = System.Drawing.Color.DarkGray;
            this.txtdp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdp.Location = new System.Drawing.Point(212, 223);
            this.txtdp.Name = "txtdp";
            this.txtdp.ReadOnly = true;
            this.txtdp.Size = new System.Drawing.Size(156, 20);
            this.txtdp.TabIndex = 42;
            this.txtdp.Text = "0.00";
            this.txtdp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkGray;
            this.label5.Location = new System.Drawing.Point(105, 223);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 20);
            this.label5.TabIndex = 41;
            this.label5.Tag = "0.00";
            this.label5.Text = "DVD price";
            // 
            // txttotal
            // 
            this.txttotal.BackColor = System.Drawing.Color.DarkGray;
            this.txttotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txttotal.Location = new System.Drawing.Point(212, 249);
            this.txttotal.Name = "txttotal";
            this.txttotal.ReadOnly = true;
            this.txttotal.Size = new System.Drawing.Size(156, 20);
            this.txttotal.TabIndex = 43;
            this.txttotal.Text = "0.00";
            this.txttotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkGray;
            this.label8.Location = new System.Drawing.Point(147, 249);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 20);
            this.label8.TabIndex = 44;
            this.label8.Tag = "0.00";
            this.label8.Text = "Total";
            // 
            // minus
            // 
            this.minus.Font = new System.Drawing.Font("Corbel", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minus.Location = new System.Drawing.Point(332, 331);
            this.minus.Name = "minus";
            this.minus.Size = new System.Drawing.Size(36, 33);
            this.minus.TabIndex = 48;
            this.minus.Text = "-";
            this.minus.UseVisualStyleBackColor = true;
            this.minus.Click += new System.EventHandler(this.minus_Click);
            // 
            // plus
            // 
            this.plus.Font = new System.Drawing.Font("Corbel", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plus.Location = new System.Drawing.Point(290, 331);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(36, 33);
            this.plus.TabIndex = 47;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = true;
            this.plus.Click += new System.EventHandler(this.plus_Click);
            // 
            // txtqty
            // 
            this.txtqty.BackColor = System.Drawing.Color.DarkGray;
            this.txtqty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtqty.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtqty.Location = new System.Drawing.Point(212, 294);
            this.txtqty.Name = "txtqty";
            this.txtqty.ReadOnly = true;
            this.txtqty.Size = new System.Drawing.Size(156, 31);
            this.txtqty.TabIndex = 46;
            this.txtqty.Text = "1";
            this.txtqty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkGray;
            this.label9.Location = new System.Drawing.Point(120, 305);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 20);
            this.label9.TabIndex = 45;
            this.label9.Text = "Quantity";
            // 
            // print
            // 
            this.print.AutoSize = true;
            this.print.Font = new System.Drawing.Font("Dodger", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.print.ForeColor = System.Drawing.Color.DarkGray;
            this.print.Location = new System.Drawing.Point(158, 382);
            this.print.Name = "print";
            this.print.Size = new System.Drawing.Size(210, 18);
            this.print.TabIndex = 49;
            this.print.Text = "Add to Cart";
            this.print.Click += new System.EventHandler(this.print_Click);
            this.print.MouseLeave += new System.EventHandler(this.print_MouseLeave);
            this.print.MouseHover += new System.EventHandler(this.print_MouseHover);
            // 
            // close
            // 
            this.close.AutoSize = true;
            this.close.BackColor = System.Drawing.Color.Transparent;
            this.close.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close.ForeColor = System.Drawing.Color.SlateGray;
            this.close.Location = new System.Drawing.Point(380, 9);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(21, 20);
            this.close.TabIndex = 50;
            this.close.Text = "X";
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // frmQty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(413, 435);
            this.Controls.Add(this.close);
            this.Controls.Add(this.print);
            this.Controls.Add(this.minus);
            this.Controls.Add(this.plus);
            this.Controls.Add(this.txtqty);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txttotal);
            this.Controls.Add(this.txtdp);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtdcd);
            this.Controls.Add(this.txtci);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtri);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtdmin);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtdpc);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtdn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtdid);
            this.Controls.Add(this.lbldvdid);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmQty";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmQty";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtci;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtri;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtdmin;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtdpc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtdn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtdid;
        private System.Windows.Forms.Label lbldvdid;
        private System.Windows.Forms.TextBox txtdcd;
        private System.Windows.Forms.TextBox txtdp;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txttotal;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button minus;
        private System.Windows.Forms.Button plus;
        private System.Windows.Forms.TextBox txtqty;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label print;
        private System.Windows.Forms.Label close;
    }
}