﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MamarilVideoShop
{
    public partial class frmVideo : Form
    {
        public frmVideo(String customid)
        {
            InitializeComponent();

            this.lblcarry.Text = customid;
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmVideo_Load(object sender, EventArgs e)
        {
            //gets the videos from database to datatable
            Video vid = new Video();
            this.dgVideo= vid.getVideoRecords(dgVideo);
            Category cat = new Category();
            this.dgCat = cat.getCatRecords(dgCat);
            Rating rate = new Rating();
            this.dgRate = rate.getRateRecords(dgRate);
            dgCat.CurrentRow.Selected = false;
            dgRate.CurrentRow.Selected = false;
            if (Convert.ToInt16(lblcarry.Text) != 1)
            {
                delete.Hide();
                add.Hide();
                update.Hide();
            }
        }

        private void add_Click(object sender, EventArgs e)
        {
            frmVideoAdd add = new frmVideoAdd();
            DialogResult dr = new DialogResult();
            dr = add.ShowDialog();
            if (dr == DialogResult.Cancel)
            {
                Video vid= new Video();
                this.dgVideo = vid.getVideoRecords(dgVideo);
            }
        }

        private void delete_Click(object sender, EventArgs e)
        {
            String dvdid = dgVideo.Rows[dgVideo.SelectedRows[0].Index].Cells[0].Value.ToString();
            String dvdname = dgVideo.Rows[dgVideo.SelectedRows[0].Index].Cells[1].Value.ToString();
            String dvdcopydate= dgVideo.Rows[dgVideo.SelectedRows[0].Index].Cells[2].Value.ToString();
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Do you really want to remove \"" + dvdname, "Removing Video", MessageBoxButtons.OKCancel);
            if (dr == DialogResult.OK)
            {



                Video vid = new Video();
                vid.deleteVideo(dvdid);
                this.dgVideo = vid.getVideoRecords(dgVideo);

            }
        }

        private void dgCat_SelectionChanged(object sender, EventArgs e)
        {
            this.dgCat.ClearSelection();
            this.dgRate.ClearSelection();
        }

        private void update_Click(object sender, EventArgs e)
        {
            String dvdid = dgVideo.Rows[dgVideo.SelectedRows[0].Index].Cells[0].Value.ToString();
            String dvdname = dgVideo.Rows[dgVideo.SelectedRows[0].Index].Cells[1].Value.ToString();
            String dvdcopydate = dgVideo.Rows[dgVideo.SelectedRows[0].Index].Cells[2].Value.ToString();
            String dvdprodcompany = dgVideo.Rows[dgVideo.SelectedRows[0].Index].Cells[3].Value.ToString();
            String dvdminutes = dgVideo.Rows[dgVideo.SelectedRows[0].Index].Cells[4].Value.ToString();
            String ratingid = dgVideo.Rows[dgVideo.SelectedRows[0].Index].Cells[5].Value.ToString();
            String categoryid = dgVideo.Rows[dgVideo.SelectedRows[0].Index].Cells[6].Value.ToString();
            String dvdprice = dgVideo.Rows[dgVideo.SelectedRows[0].Index].Cells[7].Value.ToString();
            

            frmVideoUpdate update = new frmVideoUpdate(dvdid,dvdname,dvdcopydate,dvdprodcompany,dvdminutes,ratingid,categoryid,dvdprice);

            DialogResult dr = new DialogResult();
            dr = update.ShowDialog();
            if (dr == DialogResult.Cancel)
            {
                Video vid = new Video();
                this.dgVideo = vid.getVideoRecords(dgVideo);
            }
        }
    }
}
