﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MamarilVideoShop
{
    public partial class frmQty : Form
    {
        public String dvdid { get; set; }
        public String dvdname { get; set; }
        public String dvdcopydate { get; set; }
        public String dvdprodcompany { get; set; }
        public String dvdminutes { get; set; }
        public String ratingid { get; set; }
        public String catid { get; set; }
        public String dvdprice { get; set; }
        public String qty { get; set; }
        public String totalprice { get; set; }
        public frmQty(String dvdid, String dvdname, String dvdcopydate, String dvdprodcompany, String dvdminutes, String ratingid, String catid, String dvdprice)
        {
            InitializeComponent();
            this.txtdid.Text = dvdid;
            this.txtdn.Text = dvdname;
            this.txtdcd.Text = dvdcopydate;
            this.txtdpc.Text = dvdprodcompany;
            this.txtdmin.Text = dvdminutes;
            this.txtri.Text = ratingid;
            this.txtci.Text = catid;
            this.txtdp.Text = dvdprice;

            double dp = Double.Parse(txtdp.Text);
            double total = dp * 1;
            this.txttotal.Text = total.ToString();
        }

        private void print_MouseHover(object sender, EventArgs e)
        {
            print.ForeColor = Color.Maroon;
        }

        private void print_MouseLeave(object sender, EventArgs e)
        {
            print.ForeColor = Color.DarkGray;
        }

        private void print_Click(object sender, EventArgs e)
        {
            this.dvdid= txtdid.Text;
            this.dvdname= txtdn.Text;
            this.dvdcopydate=txtdcd.Text;
            this.dvdprodcompany=txtdpc.Text;
            this.dvdminutes=txtdmin.Text;
            this.ratingid=txtri.Text;
            this.catid = txtci.Text ;
            this.dvdprice=txtdp.Text;
            this.totalprice = txttotal.Text;
            this.qty = txtqty.Text;

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void plus_Click(object sender, EventArgs e)
        {
            int qty = Int16.Parse(txtqty.Text);
            qty += 1;
            txtqty.Text = qty.ToString();

            double dvdprice = Double.Parse(txtdp.Text);
            double total = dvdprice * qty;
            txttotal.Text = total.ToString();
        }

        private void minus_Click(object sender, EventArgs e)
        {
            int qty = Int16.Parse(txtqty.Text);
            if (qty > 1)
            {
                qty -= 1;
                txtqty.Text = qty.ToString();

                double dvdprice = Double.Parse(txtdp.Text);
                double total = dvdprice * qty;
                txttotal.Text = total.ToString();


            }
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
