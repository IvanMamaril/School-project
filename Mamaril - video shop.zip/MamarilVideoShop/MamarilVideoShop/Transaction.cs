using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System.Data;

namespace MamarilVideoShop
{
    class Transaction
    {
        MySqlConnection conn = null;

        public Transaction()
        {
            String hostname = "localhost";
            String database = "videoshop";
            String username = "root";
            String password = "";

            conn = new MySqlConnection(
                "host=" + hostname +
                ";database=" + database +
                ";username=" + username +
                ";password=" + password + ";");
        }

        private bool Open()
        {
            try
            {
                conn.Open();
                return true;
            }
            catch
            {
                MessageBox.Show("Unable to connect to database!");
                return false;
            }
        }

        private bool Close()
        {
            try
            {
                conn.Close();
                return true;
            }
            catch
            {
                MessageBox.Show("Unable to connect to database!");
                return false;
            }
        }

        public String confirmItemRequest(DataGridView dgPrint)
        {
            String table = "transaction";
            String columns = "transactionid,transactiondvdname,transactionqty,transactionprice,transactiontotal";
            String transactionid = DateTime.Now.ToString();
            for (int i = 0; i < dgPrint.RowCount; i++)
            {

                String transactiondvdname = dgPrint.Rows[i].Cells[0].FormattedValue.ToString();
                String transactionqty = dgPrint.Rows[i].Cells[1].FormattedValue.ToString();
                String transactionprice = dgPrint.Rows[i].Cells[2].FormattedValue.ToString();
                String transactiontotal = dgPrint.Rows[i].Cells[3].FormattedValue.ToString();


                String query = "INSERT INTO " + table +
                                    " (" + columns +
                            ") VALUES ('" + transactionid + "'," +
                                    "'" + transactiondvdname + "'," +
                                    "'" + transactionqty + "'," +
                                    "'" + transactionprice + "'," +
                                    "'" + transactiontotal + "')";
                try
                {
                    if (this.Open())
                    {                        
                        MySqlCommand cmd = new MySqlCommand(query, conn);
                        cmd.ExecuteNonQuery();
                        this.Close();
                    }
                }
                catch { }
            }
            return transactionid;
        }

        public DataGridView getTransactionRecord(String transactionid,DataGridView datagrid)
        {
            String table = "transaction";
            String where = "transactionid='"+transactionid+"'";
            String query = "select transactiondvdname as 'Name', " +
                           " transactionprice as 'Price', " + 
                           " transactionqty as 'Qty', " + 
                           " transactiontotal as 'Total' " + 
                           " from " + table + " WHERE " + where;

            MySqlDataAdapter da = null;
            DataSet ds = null;
            conn.Open();
            ds = new DataSet();
            da = new MySqlDataAdapter(query, conn);
            da.Fill(ds, table);

            datagrid.DataSource = ds.Tables[table];
            return datagrid;
        }
    }
}

