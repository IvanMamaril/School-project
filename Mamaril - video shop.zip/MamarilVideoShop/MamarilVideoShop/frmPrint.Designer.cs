﻿namespace MamarilVideoShop
{
    partial class frmPrint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblcarry = new System.Windows.Forms.Label();
            this.lblchange = new System.Windows.Forms.Label();
            this.lblpaid = new System.Windows.Forms.Label();
            this.lbltotal = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.date = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dgPrint1 = new System.Windows.Forms.DataGridView();
            this.close = new System.Windows.Forms.Label();
            this.duedate = new System.Windows.Forms.Label();
            this.duefail = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPrint1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.duefail);
            this.panel1.Controls.Add(this.duedate);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.lblcarry);
            this.panel1.Controls.Add(this.lblchange);
            this.panel1.Controls.Add(this.lblpaid);
            this.panel1.Controls.Add(this.lbltotal);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.date);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.dgPrint1);
            this.panel1.ForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(37, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(268, 532);
            this.panel1.TabIndex = 35;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(253, 13);
            this.label2.TabIndex = 49;
            this.label2.Text = "=========================================";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(73, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(122, 13);
            this.label7.TabIndex = 48;
            this.label7.Text = "Serial #: SGH342PHMQ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(224, 13);
            this.label6.TabIndex = 47;
            this.label6.Text = "PN #:0314-132-182810-036 MIN#: 14034950";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(63, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(143, 13);
            this.label4.TabIndex = 45;
            this.label4.Text = "TIN #: 005-158-986-036VAT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(217, 13);
            this.label3.TabIndex = 44;
            this.label3.Text = "123 GEN. MALVAR STREET, DAVAO CITY";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(45, 24);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(172, 13);
            this.label19.TabIndex = 43;
            this.label19.Text = "MAMARIL VIDEO SHOP INC.";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(63, 63);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(36, 13);
            this.label18.TabIndex = 42;
            this.label18.Text = "ACN#";
            // 
            // lblcarry
            // 
            this.lblcarry.AutoSize = true;
            this.lblcarry.ForeColor = System.Drawing.Color.Black;
            this.lblcarry.Location = new System.Drawing.Point(97, 63);
            this.lblcarry.Name = "lblcarry";
            this.lblcarry.Size = new System.Drawing.Size(25, 13);
            this.lblcarry.TabIndex = 41;
            this.lblcarry.Text = "000";
            // 
            // lblchange
            // 
            this.lblchange.AutoSize = true;
            this.lblchange.ForeColor = System.Drawing.Color.Black;
            this.lblchange.Location = new System.Drawing.Point(124, 378);
            this.lblchange.Name = "lblchange";
            this.lblchange.Size = new System.Drawing.Size(28, 13);
            this.lblchange.TabIndex = 40;
            this.lblchange.Text = "0.00";
            // 
            // lblpaid
            // 
            this.lblpaid.AutoSize = true;
            this.lblpaid.ForeColor = System.Drawing.Color.Black;
            this.lblpaid.Location = new System.Drawing.Point(124, 353);
            this.lblpaid.Name = "lblpaid";
            this.lblpaid.Size = new System.Drawing.Size(28, 13);
            this.lblpaid.TabIndex = 39;
            this.lblpaid.Text = "0.00";
            // 
            // lbltotal
            // 
            this.lbltotal.AutoSize = true;
            this.lbltotal.ForeColor = System.Drawing.Color.Black;
            this.lbltotal.Location = new System.Drawing.Point(124, 331);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(28, 13);
            this.lbltotal.TabIndex = 38;
            this.lbltotal.Text = "0.00";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(47, 378);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(58, 13);
            this.label17.TabIndex = 37;
            this.label17.Text = "CHANGE :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(47, 353);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 13);
            this.label16.TabIndex = 36;
            this.label16.Text = "PAID        :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(47, 331);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 35;
            this.label1.Text = "TOTAL    :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(5, 455);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(253, 13);
            this.label12.TabIndex = 28;
            this.label12.Text = "=========================================";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(5, 429);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(253, 13);
            this.label9.TabIndex = 25;
            this.label9.Text = "=========================================";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(39, 494);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(189, 13);
            this.label14.TabIndex = 30;
            this.label14.Text = "Bring this Receipt in case of Return or ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(72, 481);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(123, 13);
            this.label13.TabIndex = 29;
            this.label13.Text = "Thank You Come Again!";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(34, 507);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(194, 13);
            this.label15.TabIndex = 31;
            this.label15.Text = "Exchange of merchandise within 7 days";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(45, 468);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(177, 13);
            this.label11.TabIndex = 27;
            this.label11.Text = "THIS IS YOUR OFFICIAL RECEIPT";
            // 
            // date
            // 
            this.date.AutoSize = true;
            this.date.ForeColor = System.Drawing.Color.Black;
            this.date.Location = new System.Drawing.Point(160, 442);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(83, 13);
            this.date.TabIndex = 0;
            this.date.Text = "10/10/10 10:10";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(20, 442);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(145, 13);
            this.label10.TabIndex = 26;
            this.label10.Text = "R002 T3141 OR No: 064896";
            // 
            // dgPrint1
            // 
            this.dgPrint1.AllowUserToAddRows = false;
            this.dgPrint1.AllowUserToDeleteRows = false;
            this.dgPrint1.AllowUserToResizeColumns = false;
            this.dgPrint1.AllowUserToResizeRows = false;
            this.dgPrint1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgPrint1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgPrint1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgPrint1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPrint1.GridColor = System.Drawing.SystemColors.Control;
            this.dgPrint1.Location = new System.Drawing.Point(8, 120);
            this.dgPrint1.MultiSelect = false;
            this.dgPrint1.Name = "dgPrint1";
            this.dgPrint1.ReadOnly = true;
            this.dgPrint1.RowHeadersVisible = false;
            this.dgPrint1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgPrint1.Size = new System.Drawing.Size(250, 179);
            this.dgPrint1.TabIndex = 34;
            // 
            // close
            // 
            this.close.AutoSize = true;
            this.close.BackColor = System.Drawing.Color.Transparent;
            this.close.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close.ForeColor = System.Drawing.Color.SlateGray;
            this.close.Location = new System.Drawing.Point(310, 9);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(21, 20);
            this.close.TabIndex = 36;
            this.close.Text = "X";
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // duedate
            // 
            this.duedate.ForeColor = System.Drawing.Color.Black;
            this.duedate.Location = new System.Drawing.Point(8, 401);
            this.duedate.Name = "duedate";
            this.duedate.Size = new System.Drawing.Size(253, 18);
            this.duedate.TabIndex = 50;
            this.duedate.Text = "due date";
            // 
            // duefail
            // 
            this.duefail.ForeColor = System.Drawing.Color.Black;
            this.duefail.Location = new System.Drawing.Point(8, 419);
            this.duefail.Name = "duefail";
            this.duefail.Size = new System.Drawing.Size(250, 16);
            this.duefail.TabIndex = 51;
            this.duefail.Text = "due date";
            // 
            // frmPrint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(343, 582);
            this.Controls.Add(this.close);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmPrint";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmprint";
            this.Load += new System.EventHandler(this.frmPrint_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPrint1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblcarry;
        private System.Windows.Forms.Label lblchange;
        private System.Windows.Forms.Label lblpaid;
        private System.Windows.Forms.Label lbltotal;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label date;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dgPrint1;
        private System.Windows.Forms.Label close;
        private System.Windows.Forms.Label duedate;
        private System.Windows.Forms.Label duefail;

    }
}