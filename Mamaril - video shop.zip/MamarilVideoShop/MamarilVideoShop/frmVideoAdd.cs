﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

using MySql.Data.MySqlClient;

namespace MamarilVideoShop
{
    public partial class frmVideoAdd : Form
    {
        public frmVideoAdd()
        {
            InitializeComponent();
        }

        bool CheckDuplicateCustomer(int dvdid)
        {
            MySqlConnection con = new MySqlConnection();
            String hostname = "localhost";
            String database = "videoshop";
            String username = "root";
            String password = "";
            con = new MySqlConnection(
                "host=" + hostname +
                ";database=" + database +
                ";username=" + username +
                ";password=" + password + ";");

            con.Open();
            int CustomerCount = 0;
            if (con.State == System.Data.ConnectionState.Open)
            {
                MySqlCommand cmd = new MySqlCommand("select count(*) from video where dvdid = @dvdid", con);
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@dvdid", dvdid);
                CustomerCount = Convert.ToInt32(cmd.ExecuteScalar());
            }
            con.Close();
            if (CustomerCount > 0)
                return true;
            return false;
        }

        private void lbladd_Click(object sender, EventArgs e)
        {
            //checking each field must be filled
            if (txtdid.Text.Trim().Length == 0)
            {
                MessageBox.Show("Must fill-out Empty Fields!");
            }
            else
            {
                if (CheckDuplicateCustomer(Convert.ToInt16(txtdid.Text)))
                {
                    MessageBox.Show("Video Already Exists with ID " + txtdid.Text);
                }
                else
                {
                    if (txtdid.Text.Trim().Length == 0)
                    { MessageBox.Show("Must fill-out Empty Fields!"); }
                    else
                    {
                        if (txtdn.Text.Trim().Length == 0)
                        { MessageBox.Show("Must fill-out Empty Fields!"); }
                        else
                        {
                            if (txtdcd.Text.Trim().Length == 0)
                            { MessageBox.Show("Must fill-out Empty Fields!"); }
                            else
                            {
                                if (txtdpc.Text.Trim().Length == 0)
                                { MessageBox.Show("Must fill-out Empty Fields!"); }
                                else
                                {
                                    if (txtdmin.Text.Trim().Length == 0)
                                    { MessageBox.Show("Must fill-out Empty Fields!"); }
                                    else
                                    {
                                        if (txtdp.Text.Trim().Length == 0)
                                        {
                                            MessageBox.Show("Must fill-out Empty Fields!");
                                        }
                                        else
                                        {
                                            Video vid = new Video();
                                            vid.newVideo(txtdid.Text, txtdn.Text, txtdcd.Text, txtdpc.Text, txtdmin.Text, txtri.Text, txtci.Text, txtdp.Text, ofd);



                                            MessageBox.Show("Video has been added Successfuly!");

                                            this.Close();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        OpenFileDialog ofd;
        private void browse_Click(object sender, EventArgs e)
        {
            //opens image
            try
            {
                ofd = new OpenFileDialog();
                ofd.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp"; 

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    piccover.Image = new Bitmap(ofd.FileName);
                    String[] data = ofd.FileName.Split('\\');
                    int l = data.Length;
                    txtimage.Text = data[l - 1];
                } 


            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }

    }
