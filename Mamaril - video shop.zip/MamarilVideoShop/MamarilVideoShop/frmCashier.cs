﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MamarilVideoShop
{
    public partial class frmCashier : Form
    {
        double request_totalprice = 0;
        double pay = 0;
        public frmCashier(String carry)
        {
            InitializeComponent();
            lblcarry.Text = carry;
        }

        private void print_MouseHover(object sender, EventArgs e)
        {
            
            print.ForeColor = Color.Maroon;
        }

        private void print_MouseLeave(object sender, EventArgs e)
        {
            print.ForeColor = Color.DarkGray;
            
        }

        private void search_MouseHover(object sender, EventArgs e)
        {
            search.ForeColor = Color.Maroon;
        }

        private void search_MouseLeave(object sender, EventArgs e)
        {
            search.ForeColor = Color.DarkGray;
        }

        private void search_Click(object sender, EventArgs e)
        {
            Cashiering cashier = new Cashiering();
            dgItemSearch = cashier.searchItemCode(dgItemSearch, txtsearch.Text);
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgItemSearch_Click(object sender, EventArgs e)
        {
            //Item press, opens quantity form
            String dvdid = dgItemSearch.Rows[dgItemSearch.SelectedRows[0].Index].Cells[0].Value.ToString();
            String dvdname = dgItemSearch.Rows[dgItemSearch.SelectedRows[0].Index].Cells[1].Value.ToString();
            String dvdcopydate = dgItemSearch.Rows[dgItemSearch.SelectedRows[0].Index].Cells[2].Value.ToString();
            String dvdprodcompany = dgItemSearch.Rows[dgItemSearch.SelectedRows[0].Index].Cells[3].Value.ToString();
            String dvdminutes = dgItemSearch.Rows[dgItemSearch.SelectedRows[0].Index].Cells[4].Value.ToString();
            String ratingid = dgItemSearch.Rows[dgItemSearch.SelectedRows[0].Index].Cells[5].Value.ToString();
            String catid = dgItemSearch.Rows[dgItemSearch.SelectedRows[0].Index].Cells[6].Value.ToString();
            String dvdprice = dgItemSearch.Rows[dgItemSearch.SelectedRows[0].Index].Cells[7].Value.ToString();

            frmQty cashier = new frmQty(dvdid,dvdname,dvdcopydate,dvdprodcompany,dvdminutes,ratingid,catid,dvdprice);

            DialogResult dr = cashier.ShowDialog();
            if (dr == DialogResult.OK)
            {
                double temp = 0;
                String request_qty = cashier.qty;
                String request_storeprice = cashier.totalprice;
                string[] item = new string[] {dvdid, request_qty, dvdprice, request_storeprice };
                this.dgPrint.Rows.Add(item);

                MessageBox.Show("Total Price is: " + request_storeprice);
                request_totalprice = request_totalprice + Convert.ToDouble(request_storeprice);
                this.totalprice.Text = Convert.ToString(request_totalprice);
                temp = 0 - request_totalprice;
                this.txtchange.Text = temp.ToString();
                Cashiering c = new Cashiering();
                this.totalprice.Text = c.calculateTotalItemRequest(dgPrint);

            }
            else
            {
                MessageBox.Show("Item Cancel");
            }
        }

        private void frmCashier_Load(object sender, EventArgs e)
        {
            //loads dvd table
            Cashiering cashier = new Cashiering();
            dgItemSearch = cashier.searchItemCode(dgItemSearch, txtsearch.Text);

            this.dgPrint.Columns.Add("dvdnid", "DvdID");
            this.dgPrint.Columns.Add("dvdquantity", "Dvdquantity");
            this.dgPrint.Columns.Add("dvdprice", "Dvdprice");
            this.dgPrint.Columns.Add("totalprice", "Total");
        }

        private void txtpay_TextChanged(object sender, EventArgs e)
        {
            //payment system
            String change = " ";
            if (txtpay.Text == "")
            {
                txtpay.Text = "0.00";
            }
                pay = double.Parse(txtpay.Text);
                double total = 0;
                total = pay - double.Parse(totalprice.Text);
                change = total.ToString();
                this.txtchange.Text = change;
            
        }

        private void print_Click(object sender, EventArgs e)
        {
            //prints a receipt
            if (Convert.ToDouble(txtpay.Text) != 0)
            {
                Transaction tr = new Transaction();
                String transactionid = tr.confirmItemRequest(dgPrint);

                Sales s = new Sales();
                s.newSale(transactionid, totalprice.Text, txtpay.Text);

                frmPrint print = new frmPrint(transactionid, lblcarry.Text);
                print.ShowDialog();
            }
            else
            {
                MessageBox.Show("No Pay! No Play!");
            }
        }

        private void txtpay_KeyPress(object sender, KeyPressEventArgs e)
        {
            //limits character to period and numbers
            if (!char.IsControl(e.KeyChar)
                   && !char.IsDigit(e.KeyChar)
                   && e.KeyChar != '.' && e.KeyChar != ',')
            {
                e.Handled = true;
            }
            if (!char.IsControl(e.KeyChar)
        && !char.IsDigit(e.KeyChar)
        && e.KeyChar != '.' && e.KeyChar != ',')
            {
                e.Handled = true;
            }
        }
    }
}
