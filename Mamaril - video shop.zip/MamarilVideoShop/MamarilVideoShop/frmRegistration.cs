﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using MySql.Data.MySqlClient;

namespace MamarilVideoShop
{
    public partial class frmRegistration : Form
    {
        public frmRegistration()
        {
            InitializeComponent();
        }

        private void frmRegistration_Load(object sender, EventArgs e)
        {
            txtcad.Text = System.DateTime.Now.ToShortDateString();
            txtccd.Text = System.DateTime.Now.AddMonths(6).ToShortDateString().ToString();
        }

        private void lblregister_MouseHover(object sender, EventArgs e)
        {
            lblregister.ForeColor = Color.Maroon;
        }


        bool CheckDuplicateCustomer(int customerid)
        {
            MySqlConnection con = new MySqlConnection();
            String hostname = "localhost";
            String database = "videoshop";
            String username = "root";
            String password = "";
            con = new MySqlConnection(
                "host=" + hostname +
                ";database=" + database +
                ";username=" + username +
                ";password=" + password + ";");

            con.Open();
            int CustomerCount = 0;
            if (con.State == System.Data.ConnectionState.Open)
            {
                MySqlCommand cmd = new MySqlCommand("select count(*) from customer where customerid = @customerid", con);
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Parameters.AddWithValue("@customerid", customerid);
                CustomerCount = Convert.ToInt32(cmd.ExecuteScalar());
            }
            con.Close();
            if (CustomerCount > 0)
                return true;
            return false;
        }


        private void lblregister_Click(object sender, EventArgs e)
        {
            //Required Fields
            {
                if (txtcid.Text.Trim().Length == 0)
                { MessageBox.Show("Must fill-out Empty Fields!"); }
                else
                { if (txtcp.Text.Trim().Length == 0 )
                { MessageBox.Show("Must fill-out Empty Fields!"); }
                else
                { if (txtcfn.Text.Trim().Length == 0 )
                { MessageBox.Show("Must fill-out Empty Fields!"); }
                else
                { if (txtcln.Text.Trim().Length == 0 )
                { MessageBox.Show("Must fill-out Empty Fields!"); }
                else
                { if (txtca.Text.Trim().Length == 0 )
                { MessageBox.Show("Must fill-out Empty Fields!"); }
                else
                { if (txtcphone.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Must fill-out Empty Fields!");
                }
                else
                {
                    if (CheckDuplicateCustomer(Convert.ToInt16(txtcid.Text)))
                    {
                        MessageBox.Show("Customer Already Exists with ID " + txtcid.Text);
                    }

                    else
                    {
                        User user = new User();
                        user.newUser(txtcid.Text, txtcp.Text, txtcfn.Text, txtcln.Text, txtca.Text, txtcphone.Text, txtcad.Text, txtccd.Text, System.DateTime.Now.ToShortDateString());
                        MessageBox.Show(txtcfn.Text + " have been registered successfully!");
                        this.Close();
                    }
                }}}}}}
                
                
                
                
                
            }
        }

        private void lblregister_MouseLeave(object sender, EventArgs e)
        {
            lblregister.ForeColor = Color.DarkGray;
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void txtcphone_KeyPress(object sender, KeyPressEventArgs e)
        {
            //limits characters to numbers
            if (Char.IsDigit(e.KeyChar) == Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
