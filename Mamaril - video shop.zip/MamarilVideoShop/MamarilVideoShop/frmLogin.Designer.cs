﻿namespace MamarilVideoShop
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.videoshop = new System.Windows.Forms.Label();
            this.customID = new System.Windows.Forms.Label();
            this.customPass = new System.Windows.Forms.Label();
            this.txtcid = new System.Windows.Forms.TextBox();
            this.txtcp = new System.Windows.Forms.TextBox();
            this.lbllogin = new System.Windows.Forms.Label();
            this.lblclear = new System.Windows.Forms.Label();
            this.lblregister = new System.Windows.Forms.Label();
            this.close = new System.Windows.Forms.Label();
            this.lbldate = new System.Windows.Forms.Label();
            this.lblactive = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // videoshop
            // 
            this.videoshop.AutoSize = true;
            this.videoshop.Font = new System.Drawing.Font("Dodger", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.videoshop.ForeColor = System.Drawing.Color.DarkGray;
            this.videoshop.Location = new System.Drawing.Point(141, 48);
            this.videoshop.Name = "videoshop";
            this.videoshop.Size = new System.Drawing.Size(269, 26);
            this.videoshop.TabIndex = 0;
            this.videoshop.Text = "VIDEO SHOP";
            // 
            // customID
            // 
            this.customID.AutoSize = true;
            this.customID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customID.ForeColor = System.Drawing.Color.DarkGray;
            this.customID.Location = new System.Drawing.Point(79, 109);
            this.customID.Name = "customID";
            this.customID.Size = new System.Drawing.Size(110, 20);
            this.customID.TabIndex = 1;
            this.customID.Text = "Customer ID";
            // 
            // customPass
            // 
            this.customPass.AutoSize = true;
            this.customPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customPass.ForeColor = System.Drawing.Color.DarkGray;
            this.customPass.Location = new System.Drawing.Point(103, 129);
            this.customPass.Name = "customPass";
            this.customPass.Size = new System.Drawing.Size(86, 20);
            this.customPass.TabIndex = 2;
            this.customPass.Text = "Password";
            // 
            // txtcid
            // 
            this.txtcid.BackColor = System.Drawing.Color.DarkGray;
            this.txtcid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtcid.Location = new System.Drawing.Point(195, 109);
            this.txtcid.Name = "txtcid";
            this.txtcid.Size = new System.Drawing.Size(181, 20);
            this.txtcid.TabIndex = 3;
            this.txtcid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcid_KeyPress);
            // 
            // txtcp
            // 
            this.txtcp.BackColor = System.Drawing.Color.DarkGray;
            this.txtcp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtcp.Location = new System.Drawing.Point(195, 135);
            this.txtcp.Name = "txtcp";
            this.txtcp.Size = new System.Drawing.Size(181, 20);
            this.txtcp.TabIndex = 4;
            this.txtcp.UseSystemPasswordChar = true;
            // 
            // lbllogin
            // 
            this.lbllogin.AutoSize = true;
            this.lbllogin.BackColor = System.Drawing.Color.Transparent;
            this.lbllogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllogin.ForeColor = System.Drawing.Color.SpringGreen;
            this.lbllogin.Location = new System.Drawing.Point(191, 158);
            this.lbllogin.Name = "lbllogin";
            this.lbllogin.Size = new System.Drawing.Size(53, 20);
            this.lbllogin.TabIndex = 5;
            this.lbllogin.Text = "Login";
            this.lbllogin.Click += new System.EventHandler(this.lbllogin_Click);
            // 
            // lblclear
            // 
            this.lblclear.AutoSize = true;
            this.lblclear.BackColor = System.Drawing.Color.Transparent;
            this.lblclear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblclear.ForeColor = System.Drawing.Color.Crimson;
            this.lblclear.Location = new System.Drawing.Point(191, 198);
            this.lblclear.Name = "lblclear";
            this.lblclear.Size = new System.Drawing.Size(51, 20);
            this.lblclear.TabIndex = 6;
            this.lblclear.Text = "Clear";
            this.lblclear.Click += new System.EventHandler(this.lblclear_Click);
            // 
            // lblregister
            // 
            this.lblregister.AutoSize = true;
            this.lblregister.BackColor = System.Drawing.Color.Transparent;
            this.lblregister.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblregister.ForeColor = System.Drawing.Color.GhostWhite;
            this.lblregister.Location = new System.Drawing.Point(191, 178);
            this.lblregister.Name = "lblregister";
            this.lblregister.Size = new System.Drawing.Size(77, 20);
            this.lblregister.TabIndex = 7;
            this.lblregister.Text = "Register";
            this.lblregister.Click += new System.EventHandler(this.lblregister_Click);
            // 
            // close
            // 
            this.close.AutoSize = true;
            this.close.BackColor = System.Drawing.Color.Transparent;
            this.close.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close.ForeColor = System.Drawing.Color.SlateGray;
            this.close.Location = new System.Drawing.Point(455, 9);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(21, 20);
            this.close.TabIndex = 8;
            this.close.Text = "X";
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // lbldate
            // 
            this.lbldate.AutoSize = true;
            this.lbldate.Font = new System.Drawing.Font("PhatBoy Slim", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldate.ForeColor = System.Drawing.Color.DarkGray;
            this.lbldate.Location = new System.Drawing.Point(27, 16);
            this.lbldate.Name = "lbldate";
            this.lbldate.Size = new System.Drawing.Size(74, 18);
            this.lbldate.TabIndex = 9;
            this.lbldate.Text = "11/11/11";
            // 
            // lblactive
            // 
            this.lblactive.AutoSize = true;
            this.lblactive.Font = new System.Drawing.Font("PhatBoy Slim", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblactive.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblactive.Location = new System.Drawing.Point(27, 34);
            this.lblactive.Name = "lblactive";
            this.lblactive.Size = new System.Drawing.Size(74, 18);
            this.lblactive.TabIndex = 10;
            this.lblactive.Text = "11/11/11";
            // 
            // frmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(488, 266);
            this.Controls.Add(this.lblactive);
            this.Controls.Add(this.lbldate);
            this.Controls.Add(this.close);
            this.Controls.Add(this.lblregister);
            this.Controls.Add(this.lblclear);
            this.Controls.Add(this.lbllogin);
            this.Controls.Add(this.txtcp);
            this.Controls.Add(this.txtcid);
            this.Controls.Add(this.customPass);
            this.Controls.Add(this.customID);
            this.Controls.Add(this.videoshop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label videoshop;
        private System.Windows.Forms.Label customID;
        private System.Windows.Forms.Label customPass;
        private System.Windows.Forms.TextBox txtcid;
        private System.Windows.Forms.TextBox txtcp;
        private System.Windows.Forms.Label lbllogin;
        private System.Windows.Forms.Label lblclear;
        private System.Windows.Forms.Label lblregister;
        private System.Windows.Forms.Label close;
        private System.Windows.Forms.Label lbldate;
        private System.Windows.Forms.Label lblactive;

    }
}

