﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MamarilVideoShop
{
    public partial class frmUserUpdate : Form
    {

        public frmUserUpdate(String customerid, String password, String customerfname, String customerlname, String customeraddress, String customerphone, String customeractivedate, String customercanceldate, String customerdatemodified)
        {
            InitializeComponent();
            this.txtcid.Text = customerid;
            this.txtcp.Text = password;
            this.txtcfn.Text = customerfname;
            this.txtcln.Text = customerlname;
            this.txtca.Text = customeraddress;
            this.txtcphone.Text = customerphone;
            this.txtcad.Text = customeractivedate;
            this.txtccd.Text = customercanceldate;
            this.txtdm.Text = customerdatemodified;

        }

        private void lblupdate_Click(object sender, EventArgs e)
        {
            User user = new User();
            user.updateUser(txtcid.Text, txtcp.Text, txtcfn.Text, txtcln.Text, txtca.Text, txtcphone.Text, txtcad.Text, txtccd.Text, txtdm.Text);
            MessageBox.Show("Customer have been updated Successfully!");
            this.Close();
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmUserUpdate_Load(object sender, EventArgs e)
        {
           txtdm.Text = System.DateTime.Now.ToShortDateString();
        }

    }
}
