﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MamarilVideoShop
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lbldate.Text = System.DateTime.Now.ToShortDateString();
        }

        private void lbllogin_Click(object sender, EventArgs e)
        {
            //Validate  if user exist
            Login login = new Login();
            User user= new User();
           // lblactive.Text =;
            bool result = login.isAccountValid(txtcid.Text, txtcp.Text, lbldate.Text);
            if (result)
            {
                frmMenu menu = new frmMenu(txtcid.Text);
                DialogResult dr = new DialogResult();
                dr = menu.ShowDialog();
                if (dr == DialogResult.Cancel)
                {
                    txtcid.Clear();
                    txtcp.Clear();
                }
               
            }
            else
            {
                MessageBox.Show("Invalid Account!");
            }
        }

        private void lblregister_Click(object sender, EventArgs e)
        {
            frmRegistration reg = new frmRegistration();
            reg.ShowDialog();
        }

        private void lblclear_Click(object sender, EventArgs e)
        {
            txtcid.Clear();
            txtcp.Clear();
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtcid_KeyPress(object sender, KeyPressEventArgs e)
        {
            //limit characters to numbers only
            if (Char.IsDigit(e.KeyChar) == Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
