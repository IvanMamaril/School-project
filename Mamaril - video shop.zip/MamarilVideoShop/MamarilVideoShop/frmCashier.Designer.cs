﻿namespace MamarilVideoShop
{
    partial class frmCashier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtchange = new System.Windows.Forms.TextBox();
            this.txtpay = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dgPrint = new System.Windows.Forms.DataGridView();
            this.dgItemSearch = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.search = new System.Windows.Forms.Label();
            this.print = new System.Windows.Forms.Label();
            this.lblcarry = new System.Windows.Forms.Label();
            this.close = new System.Windows.Forms.Label();
            this.totalprice = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgPrint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgItemSearch)).BeginInit();
            this.SuspendLayout();
            // 
            // txtchange
            // 
            this.txtchange.BackColor = System.Drawing.Color.DarkGray;
            this.txtchange.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtchange.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtchange.ForeColor = System.Drawing.Color.Black;
            this.txtchange.Location = new System.Drawing.Point(610, 341);
            this.txtchange.Name = "txtchange";
            this.txtchange.ReadOnly = true;
            this.txtchange.Size = new System.Drawing.Size(163, 26);
            this.txtchange.TabIndex = 27;
            this.txtchange.Text = "0.00";
            this.txtchange.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtpay
            // 
            this.txtpay.BackColor = System.Drawing.Color.DarkGray;
            this.txtpay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtpay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpay.ForeColor = System.Drawing.Color.Black;
            this.txtpay.Location = new System.Drawing.Point(610, 311);
            this.txtpay.Name = "txtpay";
            this.txtpay.Size = new System.Drawing.Size(163, 26);
            this.txtpay.TabIndex = 26;
            this.txtpay.Text = "0.00";
            this.txtpay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpay.TextChanged += new System.EventHandler(this.txtpay_TextChanged);
            this.txtpay.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpay_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Dodger", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkGray;
            this.label4.Location = new System.Drawing.Point(479, 351);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 16);
            this.label4.TabIndex = 25;
            this.label4.Text = "Change:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Dodger", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkGray;
            this.label3.Location = new System.Drawing.Point(448, 316);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 16);
            this.label3.TabIndex = 24;
            this.label3.Text = "Cash Paid:";
            // 
            // dgPrint
            // 
            this.dgPrint.AllowUserToAddRows = false;
            this.dgPrint.AllowUserToDeleteRows = false;
            this.dgPrint.AllowUserToResizeColumns = false;
            this.dgPrint.AllowUserToResizeRows = false;
            this.dgPrint.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgPrint.BackgroundColor = System.Drawing.Color.DarkGray;
            this.dgPrint.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPrint.Location = new System.Drawing.Point(33, 263);
            this.dgPrint.MultiSelect = false;
            this.dgPrint.Name = "dgPrint";
            this.dgPrint.ReadOnly = true;
            this.dgPrint.RowHeadersVisible = false;
            this.dgPrint.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgPrint.Size = new System.Drawing.Size(402, 186);
            this.dgPrint.TabIndex = 20;
            // 
            // dgItemSearch
            // 
            this.dgItemSearch.AllowUserToAddRows = false;
            this.dgItemSearch.AllowUserToDeleteRows = false;
            this.dgItemSearch.AllowUserToResizeColumns = false;
            this.dgItemSearch.AllowUserToResizeRows = false;
            this.dgItemSearch.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgItemSearch.BackgroundColor = System.Drawing.Color.DarkGray;
            this.dgItemSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgItemSearch.Location = new System.Drawing.Point(33, 70);
            this.dgItemSearch.MultiSelect = false;
            this.dgItemSearch.Name = "dgItemSearch";
            this.dgItemSearch.ReadOnly = true;
            this.dgItemSearch.RowHeadersVisible = false;
            this.dgItemSearch.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgItemSearch.Size = new System.Drawing.Size(609, 187);
            this.dgItemSearch.TabIndex = 19;
            this.dgItemSearch.Click += new System.EventHandler(this.dgItemSearch_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Dodger", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGray;
            this.label1.Location = new System.Drawing.Point(33, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 11);
            this.label1.TabIndex = 17;
            this.label1.Text = "Search Video";
            // 
            // txtsearch
            // 
            this.txtsearch.BackColor = System.Drawing.Color.DarkGray;
            this.txtsearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtsearch.Location = new System.Drawing.Point(33, 41);
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(177, 20);
            this.txtsearch.TabIndex = 16;
            // 
            // search
            // 
            this.search.AutoSize = true;
            this.search.Font = new System.Drawing.Font("Dodger", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search.ForeColor = System.Drawing.Color.DarkGray;
            this.search.Location = new System.Drawing.Point(216, 43);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(91, 13);
            this.search.TabIndex = 28;
            this.search.Text = "Search";
            this.search.Click += new System.EventHandler(this.search_Click);
            this.search.MouseLeave += new System.EventHandler(this.search_MouseLeave);
            this.search.MouseHover += new System.EventHandler(this.search_MouseHover);
            // 
            // print
            // 
            this.print.AutoSize = true;
            this.print.Font = new System.Drawing.Font("Dodger", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.print.ForeColor = System.Drawing.Color.DarkGray;
            this.print.Location = new System.Drawing.Point(635, 375);
            this.print.Name = "print";
            this.print.Size = new System.Drawing.Size(116, 24);
            this.print.TabIndex = 29;
            this.print.Text = "PRINT";
            this.print.Click += new System.EventHandler(this.print_Click);
            this.print.MouseLeave += new System.EventHandler(this.print_MouseLeave);
            this.print.MouseHover += new System.EventHandler(this.print_MouseHover);
            // 
            // lblcarry
            // 
            this.lblcarry.AutoSize = true;
            this.lblcarry.Font = new System.Drawing.Font("Dodger", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcarry.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblcarry.Location = new System.Drawing.Point(685, 41);
            this.lblcarry.Name = "lblcarry";
            this.lblcarry.Size = new System.Drawing.Size(0, 13);
            this.lblcarry.TabIndex = 30;
            // 
            // close
            // 
            this.close.AutoSize = true;
            this.close.BackColor = System.Drawing.Color.Transparent;
            this.close.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close.ForeColor = System.Drawing.Color.SlateGray;
            this.close.Location = new System.Drawing.Point(841, 9);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(21, 20);
            this.close.TabIndex = 31;
            this.close.Text = "X";
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // totalprice
            // 
            this.totalprice.BackColor = System.Drawing.Color.DarkGray;
            this.totalprice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalprice.ForeColor = System.Drawing.Color.Black;
            this.totalprice.Location = new System.Drawing.Point(610, 279);
            this.totalprice.Name = "totalprice";
            this.totalprice.ReadOnly = true;
            this.totalprice.Size = new System.Drawing.Size(163, 26);
            this.totalprice.TabIndex = 32;
            this.totalprice.Text = "0.00";
            this.totalprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Dodger", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkGray;
            this.label2.Location = new System.Drawing.Point(494, 284);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 16);
            this.label2.TabIndex = 33;
            this.label2.Text = "Total:";
            // 
            // frmCashier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(874, 485);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.totalprice);
            this.Controls.Add(this.close);
            this.Controls.Add(this.lblcarry);
            this.Controls.Add(this.print);
            this.Controls.Add(this.search);
            this.Controls.Add(this.txtchange);
            this.Controls.Add(this.txtpay);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dgPrint);
            this.Controls.Add(this.dgItemSearch);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtsearch);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmCashier";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmCashier";
            this.Load += new System.EventHandler(this.frmCashier_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgPrint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgItemSearch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtchange;
        private System.Windows.Forms.TextBox txtpay;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dgPrint;
        private System.Windows.Forms.DataGridView dgItemSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtsearch;
        private System.Windows.Forms.Label search;
        private System.Windows.Forms.Label print;
        private System.Windows.Forms.Label lblcarry;
        private System.Windows.Forms.Label close;
        private System.Windows.Forms.TextBox totalprice;
        private System.Windows.Forms.Label label2;
    }
}