﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using MySql.Data.MySqlClient;

namespace MamarilVideoShop
{
    public partial class frmVideoUpdate : Form
    {
        public frmVideoUpdate(String dvdid,String dvdname,String dvdcopydate,String dvdprodcompany,String dvdminutes,String ratingid,String categoryid,String dvdprice)
        {
            InitializeComponent();
            this.txtdid.Text = dvdid;
            this.txtdn.Text = dvdname;
            this.txtdcd.Text = dvdcopydate;
            this.txtdpc.Text = dvdprodcompany;
            this.txtdmin.Text = dvdminutes;
            this.txtri.Text = ratingid;
            this.txtci.Text = categoryid;
            this.txtdp.Text = dvdprice;
        }

        private void lblupdate_Click(object sender, EventArgs e)
        {
           Video vid=new Video();
           if (piccover == null || piccover.Image ==null)
           {
              vid.updateVideo(txtdid.Text, txtdn.Text, txtdcd.Text, txtdpc.Text, txtdmin.Text, txtri.Text, txtci.Text, txtdp.Text,ofd);
           }
          else
           {
               vid.updateVideo(txtdid.Text, txtdn.Text, txtdcd.Text, txtdpc.Text, txtdmin.Text, txtri.Text, txtci.Text, txtdp.Text, ofd);
           }
            
            MessageBox.Show("Video has been updated Successfuly!");
            this.Close();
        }
        OpenFileDialog ofd;
        private void browse_Click(object sender, EventArgs e)
        {
            try
            {
                ofd = new OpenFileDialog();
                ofd.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    piccover.Image = new Bitmap(ofd.FileName);
                    String[] data = ofd.FileName.Split('\\');
                    int l = data.Length;
                    txtimage.Text = data[l - 1];
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
