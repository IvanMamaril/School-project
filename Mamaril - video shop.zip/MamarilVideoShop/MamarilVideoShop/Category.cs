﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System.Data;

namespace MamarilVideoShop
{
    class Category
    {
        MySqlConnection conn = null;

        public Category()
        {
            String hostname = "localhost";
            String database = "videoshop";
            String username = "root";
            String password = "";

            conn = new MySqlConnection(
                "host=" + hostname +
                ";database=" + database +
                ";username=" + username +
                ";password=" + password + ";");
        }

        private bool Open()
        {
            try
            {
                conn.Open();
                return true;
            }
            catch
            {
                MessageBox.Show("Unable to connect to database!");
                return false;
            }
        }

        private bool Close()
        {
            try
            {
                conn.Close();
                return true;
            }
            catch
            {
                MessageBox.Show("Unable to connect to database!");
                return false;
            }
        }

        public DataGridView getCatRecords(DataGridView datagrid)
        {
            String table = "category";
            String query = "select * from " + table;

            MySqlDataAdapter da = null;
            DataSet ds = null;
            conn.Open();
            ds = new DataSet();
            da = new MySqlDataAdapter(query, conn);
            da.Fill(ds, table);

            datagrid.DataSource = ds.Tables[table];
            return datagrid;
        }

        public void newCat(String catid, String categorydesc)
        {
            String table = "category";
            String columns = "catid,categorydesc";
            String query = "INSERT INTO " + table +
                                     " (" + columns +
                             ") VALUES ('" + catid + "'," +
                                       "'" + categorydesc + "')";
            try
            {
                if (this.Open())
                {
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    this.Close();
                }
            }
            catch { }
        }

        public void updateCat(String catid, String categorydesc)
        {
            String table = "category";
            String query = "UPDATE " + table + " SET " +
                             "categorydesc='" + categorydesc + "'" +
                             " WHERE catid='" + catid + "'";
            try
            {
                if (this.Open())
                {
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    this.Close();
                }
            }
            catch { }
        }

        public void deleteCat(String catid)
        {
            String table = "category";
            String query = "DELETE FROM " + table +
                             " WHERE catid='" + catid + "'";
            try
            {
                if (this.Open())
                {
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    this.Close();
                }
            }
            catch { }
        }

        public void searchBook(String catid)
        {
            MessageBox.Show(catid);
        }
    }
}
