﻿namespace MamarilVideoShop
{
    partial class frmVideo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.close = new System.Windows.Forms.Button();
            this.update = new System.Windows.Forms.Button();
            this.delete = new System.Windows.Forms.Button();
            this.dgVideo = new System.Windows.Forms.DataGridView();
            this.add = new System.Windows.Forms.Button();
            this.dgCat = new System.Windows.Forms.DataGridView();
            this.lblcarry = new System.Windows.Forms.Label();
            this.dgRate = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgVideo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgCat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRate)).BeginInit();
            this.SuspendLayout();
            // 
            // close
            // 
            this.close.BackColor = System.Drawing.Color.DarkSlateGray;
            this.close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.close.Font = new System.Drawing.Font("01 Digitall", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close.ForeColor = System.Drawing.Color.DarkGray;
            this.close.Location = new System.Drawing.Point(676, 318);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(96, 23);
            this.close.TabIndex = 8;
            this.close.Text = "EXIT";
            this.close.UseVisualStyleBackColor = false;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // update
            // 
            this.update.BackColor = System.Drawing.Color.DarkSlateGray;
            this.update.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.update.Font = new System.Drawing.Font("01 Digitall", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update.ForeColor = System.Drawing.Color.DarkGray;
            this.update.Location = new System.Drawing.Point(472, 318);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(96, 23);
            this.update.TabIndex = 7;
            this.update.Text = "UPDATE";
            this.update.UseVisualStyleBackColor = false;
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // delete
            // 
            this.delete.BackColor = System.Drawing.Color.DarkSlateGray;
            this.delete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.delete.Font = new System.Drawing.Font("01 Digitall", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delete.ForeColor = System.Drawing.Color.DarkGray;
            this.delete.Location = new System.Drawing.Point(370, 318);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(96, 23);
            this.delete.TabIndex = 6;
            this.delete.Text = "DELETE";
            this.delete.UseVisualStyleBackColor = false;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // dgVideo
            // 
            this.dgVideo.AllowUserToAddRows = false;
            this.dgVideo.AllowUserToDeleteRows = false;
            this.dgVideo.AllowUserToResizeColumns = false;
            this.dgVideo.AllowUserToResizeRows = false;
            this.dgVideo.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgVideo.BackgroundColor = System.Drawing.Color.DarkSlateGray;
            this.dgVideo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgVideo.Location = new System.Drawing.Point(22, 53);
            this.dgVideo.MultiSelect = false;
            this.dgVideo.Name = "dgVideo";
            this.dgVideo.ReadOnly = true;
            this.dgVideo.RowHeadersVisible = false;
            this.dgVideo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgVideo.Size = new System.Drawing.Size(670, 259);
            this.dgVideo.TabIndex = 5;
            // 
            // add
            // 
            this.add.BackColor = System.Drawing.Color.DarkSlateGray;
            this.add.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.add.Font = new System.Drawing.Font("01 Digitall", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add.ForeColor = System.Drawing.Color.DarkGray;
            this.add.Location = new System.Drawing.Point(574, 318);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(96, 23);
            this.add.TabIndex = 9;
            this.add.Text = "ADD";
            this.add.UseVisualStyleBackColor = false;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // dgCat
            // 
            this.dgCat.AllowUserToAddRows = false;
            this.dgCat.AllowUserToDeleteRows = false;
            this.dgCat.AllowUserToResizeColumns = false;
            this.dgCat.AllowUserToResizeRows = false;
            this.dgCat.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgCat.BackgroundColor = System.Drawing.Color.DarkSlateGray;
            this.dgCat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgCat.Location = new System.Drawing.Point(698, 53);
            this.dgCat.MultiSelect = false;
            this.dgCat.Name = "dgCat";
            this.dgCat.ReadOnly = true;
            this.dgCat.RowHeadersVisible = false;
            this.dgCat.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgCat.Size = new System.Drawing.Size(204, 259);
            this.dgCat.TabIndex = 10;
            this.dgCat.SelectionChanged += new System.EventHandler(this.dgCat_SelectionChanged);
            // 
            // lblcarry
            // 
            this.lblcarry.AutoSize = true;
            this.lblcarry.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblcarry.Location = new System.Drawing.Point(958, 33);
            this.lblcarry.Name = "lblcarry";
            this.lblcarry.Size = new System.Drawing.Size(0, 13);
            this.lblcarry.TabIndex = 11;
            // 
            // dgRate
            // 
            this.dgRate.AllowUserToAddRows = false;
            this.dgRate.AllowUserToDeleteRows = false;
            this.dgRate.AllowUserToResizeColumns = false;
            this.dgRate.AllowUserToResizeRows = false;
            this.dgRate.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgRate.BackgroundColor = System.Drawing.Color.DarkSlateGray;
            this.dgRate.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgRate.Location = new System.Drawing.Point(908, 53);
            this.dgRate.MultiSelect = false;
            this.dgRate.Name = "dgRate";
            this.dgRate.ReadOnly = true;
            this.dgRate.RowHeadersVisible = false;
            this.dgRate.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgRate.Size = new System.Drawing.Size(204, 259);
            this.dgRate.TabIndex = 12;
            this.dgRate.SelectionChanged += new System.EventHandler(this.dgCat_SelectionChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Dodger", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGray;
            this.label1.Location = new System.Drawing.Point(19, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 16);
            this.label1.TabIndex = 25;
            this.label1.Text = "Videos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Dodger", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkGray;
            this.label2.Location = new System.Drawing.Point(695, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 16);
            this.label2.TabIndex = 26;
            this.label2.Text = "Category";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Dodger", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkGray;
            this.label3.Location = new System.Drawing.Point(905, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 16);
            this.label3.TabIndex = 27;
            this.label3.Text = "Rating";
            // 
            // frmVideo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(1143, 362);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgRate);
            this.Controls.Add(this.lblcarry);
            this.Controls.Add(this.dgCat);
            this.Controls.Add(this.add);
            this.Controls.Add(this.close);
            this.Controls.Add(this.update);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.dgVideo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmVideo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmVideo";
            this.Load += new System.EventHandler(this.frmVideo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgVideo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgCat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRate)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button close;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.DataGridView dgVideo;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.DataGridView dgCat;
        private System.Windows.Forms.Label lblcarry;
        private System.Windows.Forms.DataGridView dgRate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}