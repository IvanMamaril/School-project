﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MamarilVideoShop
{
    public partial class frmPrint : Form
    {
        public frmPrint(String transactionid, String carry)
        {
            // prints the items purchase
            InitializeComponent();
            lblcarry.Text = "000-"+carry;
            Transaction tr = new Transaction();
            dgPrint1 = tr.getTransactionRecord(transactionid, dgPrint1);

            Sales s = new Sales();
            String requesttotal = s.getRequestTotal(transactionid);
            lbltotal.Text = requesttotal;
            String amountpaid = s.getAmountPaid(transactionid);
            lblpaid.Text = amountpaid;
            double nchange=Convert.ToDouble(amountpaid)-Convert.ToDouble(requesttotal);
            lblchange.Text = nchange.ToString();
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmPrint_Load(object sender, EventArgs e)
        {
            // due date till extra charges apply
            date.Text = System.DateTime.Now.ToShortDateString() + " " + System.DateTime.Now.ToShortTimeString();
            duedate.Text ="Due date: " + System.DateTime.Now.AddDays(7).ToShortDateString();
            duefail.Text ="Failure to return before the due will cost additional fees";
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
