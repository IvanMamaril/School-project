﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System.Data;

namespace MamarilVideoShop
{
    class User
    {
        MySqlConnection conn = null;

        public User()
        {
            String hostname = "localhost";
            String database = "videoshop";
            String username = "root";
            String password = "";

            conn = new MySqlConnection(
                "host=" + hostname +
                ";database=" + database +
                ";username=" + username +
                ";password=" + password + ";");
        }

        private bool Open()
        {
            try
            {
                conn.Open();
                return true;
            }
            catch
            {
                MessageBox.Show("Unable to connect to database!");
                return false;
            }
        }

        private bool Close()
        {
            try
            {
                conn.Close();
                return true;
            }
            catch
            {
                MessageBox.Show("Unable to connect to database!");
                return false;
            }
        }

        public DataGridView getUserRecords(DataGridView datagrid)
        {
            String table = "customer";
            String query = "select * from " + table;

            MySqlDataAdapter da = null;
            DataSet ds = null;
            conn.Open();
            ds = new DataSet();
            da = new MySqlDataAdapter(query, conn);
            da.Fill(ds, table);

            datagrid.DataSource = ds.Tables[table];
            return datagrid;
        }

        public void newUser( String customerid,String password, String customerfname, String customerlname, String customeraddress, String customerphone, String customeractivedate, String customercanceldate, String customerdatemodified)
        {
            String table = "customer";
            String columns = "customerid,password,customerfname,customerlname,customeraddress,customerphone,customeractivedate,customercanceldate,customerdatemodified";
            String query = "INSERT INTO " + table +
                                     " (" + columns +
                             ") VALUES ('" + customerid + "'," +
                                       "'" + password + "'," +
                                       "'" + customerfname + "'," +
                                       "'" + customerlname + "'," +
                                       "'" + customeraddress + "'," +
                                       "'" + customerphone + "'," +
                                       "'" + customeractivedate + "'," +
                                       "'" + customercanceldate + "'," +
                                       "'" + customerdatemodified + "')";
            try
            {
                if (this.Open())
                {
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    this.Close();
                }
            }
            catch { }
        }

        public void updateUser(String customerid, String password, String customerfname, String customerlname, String customeraddress, String customerphone, String customeractivedate, String customercanceldate, String customerdatemodified)
        {
            String table = "customer";
            String query = "UPDATE " + table + " SET " +
                             "password='" + password + "'," +
                             "customerfname='" + customerfname + "'," +
                             "customerlname='" + customerlname + "'," +
                             "customeraddress='" + customeraddress + "'," +
                             "customerphone='" + customerphone + "'," +
                             "customeractivedate='" + customeractivedate + "'," +
                             "customercanceldate='" + customercanceldate + "'," +
                             "customerdatemodified='" + customerdatemodified + "'" +
                             " WHERE customerid='" + customerid + "'";
            try
            {
                if (this.Open())
                {
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    this.Close();
                }
            }
            catch { }
        }

        public void deleteUser(String customerid)
        {
            String table = "customer";
            String query = "DELETE FROM " + table +
                             " WHERE customerid='" + customerid + "'";
            try
            {
                if (this.Open())
                {
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    this.Close();
                }
            }
            catch { }
        }

        public void searchUser(String customerid)
        {
            MessageBox.Show(customerid);
        }
    }
}
