using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System.Data;

namespace MamarilVideoShop
{
    class Sales
    {
        MySqlConnection conn = null;

        public Sales()
        {
            String hostname = "localhost";
            String database = "videoshop";
            String username = "root";
            String password = "";

            conn = new MySqlConnection(
                "host=" + hostname +
                ";database=" + database +
                ";username=" + username +
                ";password=" + password + ";");
        }

        private bool Open()
        {
            try
            {
                conn.Open();
                return true;
            }
            catch
            {
                MessageBox.Show("Unable to connect to database!");
                return false;
            }
        }

        private bool Close()
        {
            try
            {
                conn.Close();
                return true;
            }
            catch
            {
                MessageBox.Show("Unable to connect to database!");
                return false;
            }
        }

        public void newSale(String transactionid,String txtTotalDisplay, String txtAmountPaid)
        {
            String table = "sales";
            String columns = "transactionid,requesttotal,amountpaid";
            String query = "INSERT INTO " + table +
                                     " (" + columns +
                             ") VALUES ('" + transactionid + "'," +                                       
                                       "'" + txtTotalDisplay + "'," +
                                       "'" + txtAmountPaid + "')";
            try
            {
                if (this.Open())
                {
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    this.Close();
                }
            }
            catch { }
        }

        public String getRequestTotal(String transactionid)
        {
            String requesttotal = "";
            String table = "sales";
            String where = " transactionid = '" + transactionid + "'";
            String query = "select requesttotal from " + table + " where " + where;

            try
            {
                if (this.Open())
                {
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    requesttotal = cmd.ExecuteScalar().ToString();
                    this.Close();
                }
            }
            catch { }

            return requesttotal;
        }

        public String getAmountPaid(String transactionid)
        {
            String amountpaid = "";
            String table = "sales";
            String where = " transactionid = '" + transactionid + "'";
            String query = "select amountpaid from " + table + " where " + where;

            try
            {
                if (this.Open())
                {
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    amountpaid = cmd.ExecuteScalar().ToString();
                    this.Close();
                }
            }
            catch { }

            return amountpaid;
        }
    }
}
