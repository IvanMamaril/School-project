﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace MamarilVideoShop
{
    class Login
    {
        String loginUser;

        MySqlConnection conn = null;

        public Login()
        {
            String hostname = "localhost";
            String database = "videoshop";
            String username = "root";
            String password = "";

            conn = new MySqlConnection(
                "host=" + hostname +
                ";database=" + database +
                ";username=" + username +
                ";password=" + password + ";");
        }

        private bool Open()
        {
            try
            {
                conn.Open();
                return true;
            }
            catch
            {
                MessageBox.Show("Unable to connect to database!");
                return false;
            }
        }

        private bool Close()
        {
            try
            {
                conn.Close();
                return true;
            }
            catch
            {
                MessageBox.Show("Unable to connect to database!");
                return false;
            }
        }

        public bool isAccountValid(String customerid, String password, String customeractivedate)
        {
            String table = "customer";
            String where = "customerid='" + customerid + "' AND password='" + password + "'";
            String query = "SELECT Count(*) FROM " + table + " WHERE " + where;

            int count = -1;
            if (customeractivedate != Convert.ToDateTime(customeractivedate).AddMonths(6).ToShortDateString())
            {
                if (this.Open() == true)
                {


                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    count = int.Parse(cmd.ExecuteScalar() + "");
                    this.Close();

                }
            }
            if (count <= 0) return false;
            else { this.loginUser = customerid; return true; }
        }
    }
}
