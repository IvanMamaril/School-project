﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MamarilVideoShop
{
    public partial class frmCustomer : Form
    {
        public frmCustomer()
        {
            InitializeComponent();
        }

        private void delete_Click(object sender, EventArgs e)
        {
            //deletes customer details
            String customerid = dgUser.Rows[dgUser.SelectedRows[0].Index].Cells[0].Value.ToString();
            String password = dgUser.Rows[dgUser.SelectedRows[0].Index].Cells[1].Value.ToString();
            String customerfname = dgUser.Rows[dgUser.SelectedRows[0].Index].Cells[2].Value.ToString();
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Do you really want to remove \"" + customerid
                + "\" by " + customerfname, "Removing Customer", MessageBoxButtons.OKCancel);
            if (dr == DialogResult.OK)
            {



                User user = new User();
                user.deleteUser(customerid);
                this.dgUser = user.getUserRecords(dgUser);

            }
        }

        private void update_Click(object sender, EventArgs e)
        {
            //update customer details
            String customerid = dgUser.Rows[dgUser.SelectedRows[0].Index].Cells[0].Value.ToString();
            String password = dgUser.Rows[dgUser.SelectedRows[0].Index].Cells[1].Value.ToString();
            String customerfname = dgUser.Rows[dgUser.SelectedRows[0].Index].Cells[2].Value.ToString();
            String customerlname = dgUser.Rows[dgUser.SelectedRows[0].Index].Cells[3].Value.ToString();
            String customeraddress = dgUser.Rows[dgUser.SelectedRows[0].Index].Cells[4].Value.ToString();
            String customerphone = dgUser.Rows[dgUser.SelectedRows[0].Index].Cells[5].Value.ToString();
            String customeractivedate = dgUser.Rows[dgUser.SelectedRows[0].Index].Cells[6].Value.ToString();
            String customercanceldate = dgUser.Rows[dgUser.SelectedRows[0].Index].Cells[7].Value.ToString();
            String customerdatemodified = dgUser.Rows[dgUser.SelectedRows[0].Index].Cells[8].Value.ToString();
        

            frmUserUpdate update = new frmUserUpdate(customerid, password, customerfname, customerlname, customeraddress, customerphone, customeractivedate, customercanceldate, customerdatemodified);

            DialogResult dr = new DialogResult();
            dr = update.ShowDialog();
            if (dr == DialogResult.Cancel)
            {
                User user = new User();
                this.dgUser = user.getUserRecords(dgUser);
            }
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmCustomer_Load(object sender, EventArgs e)
        {
            User user = new User();
            this.dgUser = user.getUserRecords(dgUser);
        }
    }
}
