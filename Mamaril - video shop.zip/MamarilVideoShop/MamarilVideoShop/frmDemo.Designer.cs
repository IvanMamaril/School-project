﻿namespace MamarilVideoShop
{
    partial class frmDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtpdemo = new System.Windows.Forms.DateTimePicker();
            this.close = new System.Windows.Forms.Label();
            this.insert = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // dtpdemo
            // 
            this.dtpdemo.Location = new System.Drawing.Point(134, 181);
            this.dtpdemo.Name = "dtpdemo";
            this.dtpdemo.Size = new System.Drawing.Size(200, 20);
            this.dtpdemo.TabIndex = 0;
            // 
            // close
            // 
            this.close.AutoSize = true;
            this.close.BackColor = System.Drawing.Color.Transparent;
            this.close.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close.ForeColor = System.Drawing.Color.SlateGray;
            this.close.Location = new System.Drawing.Point(436, 9);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(21, 20);
            this.close.TabIndex = 10;
            this.close.Text = "X";
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // insert
            // 
            this.insert.AutoSize = true;
            this.insert.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insert.ForeColor = System.Drawing.Color.DarkGray;
            this.insert.Location = new System.Drawing.Point(188, 227);
            this.insert.Name = "insert";
            this.insert.Size = new System.Drawing.Size(72, 29);
            this.insert.TabIndex = 30;
            this.insert.Text = "Insert";
            this.insert.Click += new System.EventHandler(this.insert_Click);
            this.insert.MouseLeave += new System.EventHandler(this.insert_MouseLeave);
            this.insert.MouseHover += new System.EventHandler(this.insert_MouseHover);
            // 
            // frmDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(469, 398);
            this.Controls.Add(this.insert);
            this.Controls.Add(this.close);
            this.Controls.Add(this.dtpdemo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmDemo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmDemo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtpdemo;
        private System.Windows.Forms.Label close;
        private System.Windows.Forms.Label insert;
    }
}