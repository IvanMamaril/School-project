﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System.Data;

namespace MamarilVideoShop
{
    class Cashiering
    {
        MySqlConnection conn = null;

        public Cashiering()
        {
            String hostname = "localhost";
            String database = "videoshop";
            String username = "root";
            String password = "";

            conn = new MySqlConnection(
                "host=" + hostname +
                ";database=" + database +
                ";username=" + username +
                ";password=" + password + ";");
        }

        private bool Open()
        {
            try
            {
                conn.Open();
                return true;
            }
            catch
            {
                MessageBox.Show("Unable to connect to database!");
                return false;
            }
        }

        private bool Close()
        {
            try
            {
                conn.Close();
                return true;
            }
            catch
            {
                MessageBox.Show("Unable to connect to database!");
                return false;
            }
        }

        public DataGridView searchItemCode(DataGridView datagrid, String key)
        {
            String table = "video";
            String where = " dvdid like ('%" + key + "%') OR " +
                           " dvdname like ('%" + key + "%') OR " +
                           " dvdprodcompany like ('%" + key + "%')";
            String query = "select dvdid,dvdname,dvdcopydate,dvdprodcompany,dvdminutes,ratingid,catid,dvdprice from " + table + " where " + where;

            MySqlDataAdapter da = null;
            DataSet ds = null;
            conn.Open();
            ds = new DataSet();
            da = new MySqlDataAdapter(query, conn);
            da.Fill(ds, table);

            datagrid.DataSource = ds.Tables[table];
            return datagrid;
        }
        public String calculateTotalItemRequest(DataGridView dgItemRequest)
        {
            double dtotal = 0.00;
            String stotal = "0.00";

            for (int i = 0; i < dgItemRequest.RowCount; i++)
            {
                double val = Convert.ToDouble(dgItemRequest.Rows[i].Cells[3].Value);
                dtotal += val;
            }

            dtotal = Math.Round(dtotal, 2);
            stotal = Convert.ToString(dtotal);
            return stotal;
        }

    }
}