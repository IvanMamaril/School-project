﻿namespace MamarilVideoShop
{
    partial class frmVideoUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblupdate = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtci = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtri = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtdmin = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtdpc = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtdn = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtdid = new System.Windows.Forms.TextBox();
            this.lbldvdid = new System.Windows.Forms.Label();
            this.close = new System.Windows.Forms.Label();
            this.txtdcd = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.txtdp = new System.Windows.Forms.TextBox();
            this.txtimage = new System.Windows.Forms.TextBox();
            this.browse = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.piccover = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.piccover)).BeginInit();
            this.SuspendLayout();
            // 
            // lblupdate
            // 
            this.lblupdate.AutoSize = true;
            this.lblupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblupdate.ForeColor = System.Drawing.Color.DarkGray;
            this.lblupdate.Location = new System.Drawing.Point(380, 423);
            this.lblupdate.Name = "lblupdate";
            this.lblupdate.Size = new System.Drawing.Size(119, 20);
            this.lblupdate.TabIndex = 56;
            this.lblupdate.Text = "Update Video";
            this.lblupdate.Click += new System.EventHandler(this.lblupdate_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkGray;
            this.label5.Location = new System.Drawing.Point(227, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 29);
            this.label5.TabIndex = 55;
            this.label5.Text = "Video";
            // 
            // txtci
            // 
            this.txtci.BackColor = System.Drawing.Color.DarkGray;
            this.txtci.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtci.Location = new System.Drawing.Point(231, 273);
            this.txtci.Name = "txtci";
            this.txtci.Size = new System.Drawing.Size(181, 20);
            this.txtci.TabIndex = 54;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkGray;
            this.label6.Location = new System.Drawing.Point(110, 273);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 20);
            this.label6.TabIndex = 53;
            this.label6.Text = "Category ID";
            // 
            // txtri
            // 
            this.txtri.BackColor = System.Drawing.Color.DarkGray;
            this.txtri.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtri.Location = new System.Drawing.Point(231, 247);
            this.txtri.Name = "txtri";
            this.txtri.Size = new System.Drawing.Size(181, 20);
            this.txtri.TabIndex = 52;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DarkGray;
            this.label7.Location = new System.Drawing.Point(129, 247);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 20);
            this.label7.TabIndex = 51;
            this.label7.Text = "Rating ID";
            // 
            // txtdmin
            // 
            this.txtdmin.BackColor = System.Drawing.Color.DarkGray;
            this.txtdmin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdmin.Location = new System.Drawing.Point(231, 221);
            this.txtdmin.Name = "txtdmin";
            this.txtdmin.Size = new System.Drawing.Size(181, 20);
            this.txtdmin.TabIndex = 50;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkGray;
            this.label4.Location = new System.Drawing.Point(100, 221);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 20);
            this.label4.TabIndex = 49;
            this.label4.Text = "DVD Minutes";
            // 
            // txtdpc
            // 
            this.txtdpc.BackColor = System.Drawing.Color.DarkGray;
            this.txtdpc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdpc.Location = new System.Drawing.Point(231, 195);
            this.txtdpc.Name = "txtdpc";
            this.txtdpc.Size = new System.Drawing.Size(181, 20);
            this.txtdpc.TabIndex = 48;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkGray;
            this.label3.Location = new System.Drawing.Point(42, 195);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(173, 20);
            this.label3.TabIndex = 47;
            this.label3.Text = "DVD Prod. Company";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkGray;
            this.label2.Location = new System.Drawing.Point(79, 169);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 20);
            this.label2.TabIndex = 45;
            this.label2.Text = "DVD Copy Date";
            // 
            // txtdn
            // 
            this.txtdn.BackColor = System.Drawing.Color.DarkGray;
            this.txtdn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdn.Location = new System.Drawing.Point(231, 143);
            this.txtdn.Name = "txtdn";
            this.txtdn.Size = new System.Drawing.Size(181, 20);
            this.txtdn.TabIndex = 44;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGray;
            this.label1.Location = new System.Drawing.Point(117, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 20);
            this.label1.TabIndex = 43;
            this.label1.Text = "DVD Name";
            // 
            // txtdid
            // 
            this.txtdid.BackColor = System.Drawing.Color.DarkGray;
            this.txtdid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdid.Location = new System.Drawing.Point(231, 117);
            this.txtdid.Name = "txtdid";
            this.txtdid.ReadOnly = true;
            this.txtdid.Size = new System.Drawing.Size(181, 20);
            this.txtdid.TabIndex = 42;
            // 
            // lbldvdid
            // 
            this.lbldvdid.AutoSize = true;
            this.lbldvdid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldvdid.ForeColor = System.Drawing.Color.DarkGray;
            this.lbldvdid.Location = new System.Drawing.Point(144, 117);
            this.lbldvdid.Name = "lbldvdid";
            this.lbldvdid.Size = new System.Drawing.Size(71, 20);
            this.lbldvdid.TabIndex = 41;
            this.lbldvdid.Text = "DVD ID";
            // 
            // close
            // 
            this.close.AutoSize = true;
            this.close.BackColor = System.Drawing.Color.Transparent;
            this.close.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close.ForeColor = System.Drawing.Color.SlateGray;
            this.close.Location = new System.Drawing.Point(478, 9);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(21, 20);
            this.close.TabIndex = 57;
            this.close.Text = "X";
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // txtdcd
            // 
            this.txtdcd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtdcd.Location = new System.Drawing.Point(231, 168);
            this.txtdcd.Name = "txtdcd";
            this.txtdcd.Size = new System.Drawing.Size(181, 20);
            this.txtdcd.TabIndex = 58;
            this.txtdcd.Value = new System.DateTime(2014, 12, 7, 0, 0, 0, 0);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkGray;
            this.label8.Location = new System.Drawing.Point(123, 299);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 20);
            this.label8.TabIndex = 60;
            this.label8.Text = "DVD Price";
            // 
            // txtdp
            // 
            this.txtdp.BackColor = System.Drawing.Color.DarkGray;
            this.txtdp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdp.Location = new System.Drawing.Point(231, 299);
            this.txtdp.Name = "txtdp";
            this.txtdp.Size = new System.Drawing.Size(181, 20);
            this.txtdp.TabIndex = 59;
            // 
            // txtimage
            // 
            this.txtimage.BackColor = System.Drawing.Color.DarkGray;
            this.txtimage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtimage.Location = new System.Drawing.Point(358, 380);
            this.txtimage.Name = "txtimage";
            this.txtimage.ReadOnly = true;
            this.txtimage.Size = new System.Drawing.Size(141, 20);
            this.txtimage.TabIndex = 64;
            // 
            // browse
            // 
            this.browse.AutoSize = true;
            this.browse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.browse.ForeColor = System.Drawing.Color.DarkGray;
            this.browse.Location = new System.Drawing.Point(380, 403);
            this.browse.Name = "browse";
            this.browse.Size = new System.Drawing.Size(68, 20);
            this.browse.TabIndex = 63;
            this.browse.Text = "Browse";
            this.browse.Click += new System.EventHandler(this.browse_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkGray;
            this.label9.Location = new System.Drawing.Point(123, 325);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 20);
            this.label9.TabIndex = 62;
            this.label9.Text = "DVD Cover";
            // 
            // piccover
            // 
            this.piccover.BackColor = System.Drawing.Color.Honeydew;
            this.piccover.Location = new System.Drawing.Point(231, 325);
            this.piccover.Name = "piccover";
            this.piccover.Size = new System.Drawing.Size(121, 127);
            this.piccover.TabIndex = 61;
            this.piccover.TabStop = false;
            // 
            // frmVideoUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(511, 464);
            this.Controls.Add(this.txtimage);
            this.Controls.Add(this.browse);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.piccover);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtdp);
            this.Controls.Add(this.txtdcd);
            this.Controls.Add(this.close);
            this.Controls.Add(this.lblupdate);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtci);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtri);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtdmin);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtdpc);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtdn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtdid);
            this.Controls.Add(this.lbldvdid);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmVideoUpdate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmVideoUpdate";
            ((System.ComponentModel.ISupportInitialize)(this.piccover)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblupdate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtci;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtri;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtdmin;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtdpc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtdn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtdid;
        private System.Windows.Forms.Label lbldvdid;
        private System.Windows.Forms.Label close;
        private System.Windows.Forms.DateTimePicker txtdcd;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtdp;
        private System.Windows.Forms.TextBox txtimage;
        private System.Windows.Forms.Label browse;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox piccover;
    }
}