﻿namespace MamarilVideoShop
{
    partial class frmUserUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.txtcphone = new System.Windows.Forms.TextBox();
            this.txtca = new System.Windows.Forms.TextBox();
            this.txtcln = new System.Windows.Forms.TextBox();
            this.txtcfn = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtcp = new System.Windows.Forms.TextBox();
            this.txtcid = new System.Windows.Forms.TextBox();
            this.customPass = new System.Windows.Forms.Label();
            this.customID = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblupdate = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtccd = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.close = new System.Windows.Forms.Label();
            this.txtdm = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtcad = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkGray;
            this.label4.Location = new System.Drawing.Point(150, 276);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 20);
            this.label4.TabIndex = 28;
            this.label4.Text = "Phone";
            // 
            // txtcphone
            // 
            this.txtcphone.BackColor = System.Drawing.Color.DarkGray;
            this.txtcphone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtcphone.Location = new System.Drawing.Point(214, 276);
            this.txtcphone.MaxLength = 11;
            this.txtcphone.Name = "txtcphone";
            this.txtcphone.Size = new System.Drawing.Size(181, 20);
            this.txtcphone.TabIndex = 27;
            // 
            // txtca
            // 
            this.txtca.BackColor = System.Drawing.Color.DarkGray;
            this.txtca.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtca.Location = new System.Drawing.Point(214, 186);
            this.txtca.Multiline = true;
            this.txtca.Name = "txtca";
            this.txtca.Size = new System.Drawing.Size(181, 84);
            this.txtca.TabIndex = 26;
            // 
            // txtcln
            // 
            this.txtcln.BackColor = System.Drawing.Color.DarkGray;
            this.txtcln.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtcln.Location = new System.Drawing.Point(214, 160);
            this.txtcln.Name = "txtcln";
            this.txtcln.Size = new System.Drawing.Size(181, 20);
            this.txtcln.TabIndex = 25;
            // 
            // txtcfn
            // 
            this.txtcfn.BackColor = System.Drawing.Color.DarkGray;
            this.txtcfn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtcfn.Location = new System.Drawing.Point(214, 134);
            this.txtcfn.Name = "txtcfn";
            this.txtcfn.Size = new System.Drawing.Size(181, 20);
            this.txtcfn.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkGray;
            this.label3.Location = new System.Drawing.Point(135, 186);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 20);
            this.label3.TabIndex = 23;
            this.label3.Text = "Address";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkGray;
            this.label2.Location = new System.Drawing.Point(122, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 20);
            this.label2.TabIndex = 22;
            this.label2.Text = "Lastname";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGray;
            this.label1.Location = new System.Drawing.Point(121, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 20);
            this.label1.TabIndex = 21;
            this.label1.Text = "Firstname";
            // 
            // txtcp
            // 
            this.txtcp.BackColor = System.Drawing.Color.DarkGray;
            this.txtcp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtcp.Location = new System.Drawing.Point(214, 108);
            this.txtcp.Name = "txtcp";
            this.txtcp.Size = new System.Drawing.Size(181, 20);
            this.txtcp.TabIndex = 20;
            // 
            // txtcid
            // 
            this.txtcid.BackColor = System.Drawing.Color.DarkGray;
            this.txtcid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtcid.Location = new System.Drawing.Point(214, 82);
            this.txtcid.Name = "txtcid";
            this.txtcid.ReadOnly = true;
            this.txtcid.Size = new System.Drawing.Size(181, 20);
            this.txtcid.TabIndex = 19;
            // 
            // customPass
            // 
            this.customPass.AutoSize = true;
            this.customPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customPass.ForeColor = System.Drawing.Color.DarkGray;
            this.customPass.Location = new System.Drawing.Point(122, 108);
            this.customPass.Name = "customPass";
            this.customPass.Size = new System.Drawing.Size(86, 20);
            this.customPass.TabIndex = 18;
            this.customPass.Text = "Password";
            // 
            // customID
            // 
            this.customID.AutoSize = true;
            this.customID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customID.ForeColor = System.Drawing.Color.DarkGray;
            this.customID.Location = new System.Drawing.Point(98, 82);
            this.customID.Name = "customID";
            this.customID.Size = new System.Drawing.Size(110, 20);
            this.customID.TabIndex = 17;
            this.customID.Text = "Customer ID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Dodger", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DarkGray;
            this.label7.Location = new System.Drawing.Point(210, 31);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(166, 24);
            this.label7.TabIndex = 29;
            this.label7.Text = "UPDATE";
            // 
            // lblupdate
            // 
            this.lblupdate.AutoSize = true;
            this.lblupdate.Font = new System.Drawing.Font("Dodger", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblupdate.ForeColor = System.Drawing.Color.DarkGray;
            this.lblupdate.Location = new System.Drawing.Point(239, 373);
            this.lblupdate.Name = "lblupdate";
            this.lblupdate.Size = new System.Drawing.Size(116, 16);
            this.lblupdate.TabIndex = 30;
            this.lblupdate.Text = "UPDATE";
            this.lblupdate.Click += new System.EventHandler(this.lblupdate_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkGray;
            this.label6.Location = new System.Drawing.Point(108, 328);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 20);
            this.label6.TabIndex = 34;
            this.label6.Text = "Expiry Date";
            // 
            // txtccd
            // 
            this.txtccd.BackColor = System.Drawing.Color.DarkGray;
            this.txtccd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtccd.Location = new System.Drawing.Point(214, 328);
            this.txtccd.Name = "txtccd";
            this.txtccd.ReadOnly = true;
            this.txtccd.Size = new System.Drawing.Size(181, 20);
            this.txtccd.TabIndex = 33;
            this.txtccd.Text = "null";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkGray;
            this.label5.Location = new System.Drawing.Point(106, 302);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 20);
            this.label5.TabIndex = 32;
            this.label5.Text = "Active Date";
            // 
            // close
            // 
            this.close.AutoSize = true;
            this.close.BackColor = System.Drawing.Color.Transparent;
            this.close.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close.ForeColor = System.Drawing.Color.SlateGray;
            this.close.Location = new System.Drawing.Point(457, 9);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(21, 20);
            this.close.TabIndex = 35;
            this.close.Text = "X";
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // txtdm
            // 
            this.txtdm.BackColor = System.Drawing.Color.DarkGray;
            this.txtdm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdm.Location = new System.Drawing.Point(214, 354);
            this.txtdm.Name = "txtdm";
            this.txtdm.ReadOnly = true;
            this.txtdm.Size = new System.Drawing.Size(181, 20);
            this.txtdm.TabIndex = 36;
            this.txtdm.Text = "null";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkGray;
            this.label8.Location = new System.Drawing.Point(87, 354);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 20);
            this.label8.TabIndex = 37;
            this.label8.Text = "Modified Date";
            // 
            // txtcad
            // 
            this.txtcad.BackColor = System.Drawing.Color.DarkGray;
            this.txtcad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtcad.Location = new System.Drawing.Point(214, 302);
            this.txtcad.Name = "txtcad";
            this.txtcad.ReadOnly = true;
            this.txtcad.Size = new System.Drawing.Size(181, 20);
            this.txtcad.TabIndex = 31;
            this.txtcad.Text = "null";
            // 
            // frmUserUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(490, 436);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtdm);
            this.Controls.Add(this.close);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtccd);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtcad);
            this.Controls.Add(this.lblupdate);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtcphone);
            this.Controls.Add(this.txtca);
            this.Controls.Add(this.txtcln);
            this.Controls.Add(this.txtcfn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtcp);
            this.Controls.Add(this.txtcid);
            this.Controls.Add(this.customPass);
            this.Controls.Add(this.customID);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmUserUpdate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmUserUpdate";
            this.Load += new System.EventHandler(this.frmUserUpdate_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtcphone;
        private System.Windows.Forms.TextBox txtca;
        private System.Windows.Forms.TextBox txtcln;
        private System.Windows.Forms.TextBox txtcfn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtcp;
        private System.Windows.Forms.TextBox txtcid;
        private System.Windows.Forms.Label customPass;
        private System.Windows.Forms.Label customID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblupdate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtccd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label close;
        private System.Windows.Forms.TextBox txtdm;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtcad;
    }
}