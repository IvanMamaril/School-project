﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MamarilVideoShop
{
    public partial class frmMenu : Form
    {
        public frmMenu(String txtcid)
        {
            InitializeComponent();

            lblcarry.Text = txtcid;
        }

        private void picuser_MouseHover(object sender, EventArgs e)
        {
            lblpicuser.Show();
        }

        private void picuser_MouseLeave(object sender, EventArgs e)
        {
            lblpicuser.Hide();
        }

        private void piccashier_MouseHover(object sender, EventArgs e)
        {
            lblpiccashier.Show();
        }

        private void piccashier_MouseLeave(object sender, EventArgs e)
        {
            lblpiccashier.Hide();
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmMenu_Load(object sender, EventArgs e)
        {
            //check if user login is admin
            if (Convert.ToInt16(lblcarry.Text) != 1)
            {
                picuser.Hide();
            }
        }

        private void picuser_Click(object sender, EventArgs e)
        {
            frmCustomer cust = new frmCustomer();
            cust.ShowDialog();
        }

        private void picvideo_MouseHover(object sender, EventArgs e)
        {
            lblpicvideo.Show();
        }

        private void picvideo_MouseLeave(object sender, EventArgs e)
        {
            lblpicvideo.Hide();
        }

        private void picvideo_Click(object sender, EventArgs e)
        {
            frmVideo vid = new frmVideo(lblcarry.Text);
            vid.ShowDialog();
        }

        private void piccashier_Click(object sender, EventArgs e)
        {
            frmCashier cash = new frmCashier(lblcarry.Text);
            cash.ShowDialog();
        }

        private void picdemo_Click(object sender, EventArgs e)
        {
            frmDemo date = new frmDemo();
            date.ShowDialog();
        }

        private void picdemo_MouseHover(object sender, EventArgs e)
        {
            lblpicdemo.Show();
        }

        private void picdemo_MouseLeave(object sender, EventArgs e)
        {
            lblpicdemo.Hide();
        }
    }
}
